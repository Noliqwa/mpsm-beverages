<?php
// Start the session and include the database configuration
session_start();
include('config.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate form inputs
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    // Perform basic validation (you can add more)
    if (!empty($first_name) && !empty($last_name) && filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($phone)) {
        // Prepare the SQL statement to update user details
        $stmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ? WHERE id = ?");
        $stmt->bind_param("ssssi", $first_name, $last_name, $email, $phone, $user_id);

        // Execute the statement and check if the update was successful
        if ($stmt->execute()) {
            // Redirect to profile page with success message
            header("Location: changepersonalinfo.php?success=Profile updated successfully");
        } else {
            // Handle error
            echo "Error updating profile: " . $conn->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Please fill out all fields correctly.";
    }
}
?>
