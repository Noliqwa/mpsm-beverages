<?php
session_start();

// Database connection credentials
$host = "localhost";
$db_user = "bofsfkhe_mpsmecommerce";
$db_password = "PHPNRgUgRvuhJVuBR2De";
$db_name = "bofsfkhe_mpsmecommerce";

// Establish a new MySQLi connection
$conn = new mysqli($host, $db_user, $db_password, $db_name);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming `user_id` is stored in the session after user login
$userId = $_SESSION['user_id'];

// Prepare and execute the SQL query to fetch the address details
$query = "SELECT phone, street_address, suburb, city, province, postal_code, notes FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

// Check if any results were returned
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Send the address data as a JSON response
    echo json_encode([
        'success' => true,
        'phone' => $row['phone'],
        'street_address' => $row['street_address'],
        'suburb' => $row['suburb'],
        'city' => $row['city'],
        'province' => $row['province'],
        'postal_code' => $row['postal_code'],
        'notes' => $row['notes']
    ]);
} else {
    echo json_encode(['success' => false]);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
