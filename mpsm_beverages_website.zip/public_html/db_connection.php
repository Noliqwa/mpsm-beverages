<?php 
$host = "localhost";  // Database host
$db_user = "bofsfkhe_mpsmecommerce";     // Database username
$db_password = "PHPNRgUgRvuhJVuBR2De";     // Database password
$db_name = "bofsfkhe_mpsmecommerce"; // Database name

// Create connection
$conn = new mysqli($host, $db_user, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Example query to fetch notification count from a notifications table
$query = "SELECT COUNT(*) as count FROM notifications WHERE status = 'unread'";
$result = $conn->query($query);

// Initialize notification count
$notificationCount = 0;

// Check if query was successful
if ($result) {
    $row = $result->fetch_assoc();
    $notificationCount = $row['count'];
}

// Close the connection
$conn->close();
?>
