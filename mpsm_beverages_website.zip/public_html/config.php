<?php
$host = "localhost";  // database host
$db_user = "bofsfkhe_mpsmecommerce";     // database username
$db_password = "PHPNRgUgRvuhJVuBR2De";     // database password
$db_name = "bofsfkhe_mpsmecommerce"; // database name
$charset = 'utf8mb4';

// Create a database connection
$conn = mysqli_connect($host, $db_user, $db_password, $db_name);

// Check if the connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
//else{
    //echo "connection successful!!";
//}

// Example query to fetch notification count from a notifications table
$query = "SELECT COUNT(*) as count FROM notifications WHERE status = 'unread'";
$result = $conn->query($query);
if ($result) {
    $row = $result->fetch_assoc();
    $notificationCount = $row['count'];
} else {
    $notificationCount = 0; // Fallback if query fails
}
?>
