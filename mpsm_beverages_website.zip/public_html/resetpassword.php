<?php 
include 'config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$token = $_GET['token'] ?? '';
$email = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($newPassword === $confirmPassword) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Verify the token and check its expiration
        $sql = "SELECT email FROM password_resets WHERE token='$token' AND expires_at > NOW()";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) == 1) {
            $user = mysqli_fetch_assoc($result);
            $email = $user['email'];

            // Update the password in the users table
            $sql = "UPDATE users SET password='$hashedPassword' WHERE email='$email'";
            mysqli_query($conn, $sql);

            // Delete the reset token to prevent reuse
            $sql = "DELETE FROM password_resets WHERE token='$token'";
            mysqli_query($conn, $sql);

            $success = true;
        } else {
            $errorMessage = 'Invalid or expired token. Please request a new password reset.';
        }
    } else {
        $errorMessage = 'Passwords do not match. Please ensure both passwords are the same.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        /* Split the screen in half */
        .split {
            height: 100%;
            width: 50%;
            position: fixed;
            z-index: 1;
            top: 0;
            overflow-x: hidden;
            padding-top: 20px;
        }

        /* Control the left side */
        .left {
            left: 0;
            background-color: #efefef;
        }

        /* Control the right side */
        .right {
            right: 0;
            background-color: #efefef;
        }

        /* Content centered horizontally and vertically */
        .centered {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }

        /* Image styling */
        .centered img {
            width: 650px;
            border-radius: 50%;
        }

        /* Header text styling positioned on top of the image */
        .form-header {
            position: absolute;
            top: 0%;
            left: 5%;
            font-size: 5em;
            font-weight: bold;
            color: #FF6B00;
            z-index: 1;
            line-height: 1.2;
        } 
        .form-subheading{
            position: absolute;
            top: 0%;
            left: 20%;
            font-size: 7em;
            font-weight: 900;
            color: orange;
            z-index: 1;
            line-height: 1.2;
        } 

        /* Form container styling */
        .form-container {
            background: #fff;
            padding: 5rem;
            width: 90%;
            height: 90%;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
            border-radius: 12px;
            text-align: center;
        }

        /* Text styling within the form */
        .form-container p {
            font-size: 1em;
            color: #333;
            margin-bottom: 1rem;
        }

        /* Label and input styling */
        .form-container label {
            display: block;
            font-weight: bold;
            color: #555;
            text-align: left;
            margin-bottom: 0.5rem;
        }
        .form-container input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 50px;
            font-size: 1em;
            box-sizing: border-box;
            margin-bottom: 1rem;
        }

        /* Button styling */
        .form-container button {
            width: 100%;
            padding: 0.75rem;
            border: none;
            border-radius: 50px;
            background-color: orange; 
            color: white;
            font-size: 1em;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-container button:hover {
            background-color: #218838;
        }

        /* Link styling */
        .form-container a {
            color: #007bff;
            text-decoration: none;
        }

        .form-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <?php if (isset($success) && $success): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Password Updated!',
                text: 'Your password has been successfully reset.',
            }).then(function() {
                window.location.href = 'loginpage.php';
            });
        </script>
    <?php elseif (isset($errorMessage)): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: '<?php echo $errorMessage; ?>',
            });
        </script>
    <?php endif; ?>

    <div class="split left">
        <div class="form-header">Reset Your</div>
        <div class="form-subheading"><br><span>Password</span></div>
        <div class="centered">
            <img src="reset1.jpg" alt="Illustration for Reset Password">
        </div>
    </div>
    <div class="split right">
        <div class="centered">
            <form class="form-container" action="resetpassword.php" method="POST">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                <p>Enter your new password below:</p>
                
                <label for="new_password">New Password:</label>
                <input type="password" name="new_password" placeholder="Enter new password" required>
                
                <label for="confirm_password">Confirm New Password:</label>
                <input type="password" name="confirm_password" placeholder="Confirm new password" required>
                
                <button type="submit">Reset Password</button>
                
                <div>
                    <p style="margin-top: 1rem; font-size: 0.9em;">
                        Remembered your password? <a href="loginpage.php">Login Here</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
