<?php
// Start the session if it's not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection details
$host = "localhost";           // Database host
$db_user = "bofsfkhe_mpsmecommerce";             // Database username
$db_password = "PHPNRgUgRvuhJVuBR2De";             // Database password
$db_name = "bofsfkhe_mpsmecommerce";   // Database name

// Create a database connection
$conn = mysqli_connect($host, $db_user, $db_password, $db_name);

// Check if the connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("User is not logged in.");
}
$user_id = $_SESSION['user_id'];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate form inputs
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $street_address = mysqli_real_escape_string($conn, $_POST['street-address']);
    $suburb = mysqli_real_escape_string($conn, $_POST['suburb']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $province = mysqli_real_escape_string($conn, $_POST['province']);
    $postal_code = mysqli_real_escape_string($conn, $_POST['postal_code']);
    
    // Prepare the SQL statement to update the user's address
    $sql = "UPDATE users SET phone = ?, street_address = ?, suburb = ?, city = ?, province = ?, postal_code = ? WHERE id = ?";

    // Prepare the statement
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'ssssssi', $phone, $street_address, $suburb, $city, $province, $postal_code, $user_id);

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        // Successfully updated the address
        echo "Address updated successfully.";
        header("Location: homeaddress.php"); // Redirect to the profile page or address page
        exit();
    } else {
        // Error executing the statement
        echo "Error: " . mysqli_error($conn);
    }

    // Close the statement
    mysqli_stmt_close($stmt);
}

// Close the database connection
mysqli_close($conn);
?>
