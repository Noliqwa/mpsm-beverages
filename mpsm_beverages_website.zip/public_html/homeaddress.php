<?php
// Start the session if it's not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection details
$host = "localhost";           // Database host
$db_user = "bofsfkhe_mpsmecommerce";             // Database username
$db_password = "PHPNRgUgRvuhJVuBR2De";             // Database password
$db_name = "bofsfkhe_mpsmecommerce";   // Database name

// Create a database connection
$conn = mysqli_connect($host, $db_user, $db_password, $db_name);

// Check if the connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("User is not logged in.");
}
$user_id = $_SESSION['user_id'];

// Fetch the user's current address information
$sql = "SELECT phone, street_address, suburb, city, province, postal_code FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    // Fetch the data
    $user = mysqli_fetch_assoc($result);
} else {
    echo "No address found for this user.";
    exit;
}

// Close the statement and connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MPSM Beverages</title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background-color: #f9f9f9;
        }
        /*----------------- Header styling ---------------*/
header {
    position: sticky;
    top: 0;
    background-color: #fff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

/* Logo styling */
header .logo img {
    width: 200px;
    height: auto; /* Maintain aspect ratio */
}

/* Navigation styling for larger screens */
header nav.nav-menu {
    flex-grow: 1;
    display: flex;
    justify-content: center; /* Center navigation */
}

header nav.nav-menu ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
    padding: 0;

}

header nav.nav-menu ul li a {
    text-decoration: none; /* Remove underline for nav links */
    color: #333;
    font-size: 20px;
    padding: 8px 12px;
    transition: color 0.3s ease;
    
}

header nav.nav-menu ul li a:hover {
    color: #fbb01b; /* Change link color on hover */
}

/* Icons container */
header .icons {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #333b;
    margin-right: 20px;
}

header .icons i {
    font-size: 24px;
    cursor: pointer;
    transition: color 0.3s ease;
    color: black;
    
}

header .icons i:hover {
    color: orange; /* Change icon color on hover */
}

/*---------Hover effect for the navigation----------------------------*/
.hover-effect {
    transition: transform 0.3s ease, opacity 0.3s ease; /* Smooth transition */
}

.hover-effect:hover {
    transform: scale(1.1); /* Scale the image slightly */
    opacity: 0.9; /* Slightly reduce opacity on hover */
}

/* Auth links */
.auth-links {
    display: flex;
    gap: 15px;
    align-items: center;
    margin-right: 15px; /* Adjusted margin */
    justify-content: center;
}

.auth-links ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;
}

.auth-links a {
    text-decoration: none; /* Ensure no underline */
    color: inherit;
    padding: 5px 10px;
    font-size: 16px;
    transition: color 0.3s ease;
}

.auth-links a:hover {
    color: #fbb01b; /* Change color on hover */
    text-decoration: underline;
}

/* Search bar styling */
.search-container {
    display: flex;
    align-items: center;
    gap: 5px;
    flex-grow: 1; /* Allow search to take up space */
    margin-right: 10px; /* Reduced spacing */
}

#search-input {
    padding: 5px;
    width: 180px;
}

#search-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
}

#search-btn i {
    font-size: 18px;
}
.warning {
    margin-top: 20px;
    color: red;
}

.form-container {
            width: 40%;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-group small {
            color: #555;
            display: block;
            margin-top: 5px;
        }
        .form-group input[type="submit"] {
            background-color: #333;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-group input[type="submit"]:hover {
            background-color: #555;
        }

        button {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            align-self: center;
        }

        button:hover {
            background-color: #555;
        }
        footer {
            background-color: #ff790e;
            padding: 20px;
            text-align: center;
            border-top: 1px solid #ddd;
            margin-top: 20px;
        }
        footer .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }
        footer .footer-container div {
            width: 30%;
        }
        a {
        text-decoration: none;
        }
        footer .footer-container .quick-links ul {
            list-style: none;
            padding: 0;
        }
        footer .footer-container .quick-links ul li {
            margin: 5px 0;
        }
        footer .footer-container .quick-links ul li a {
            text-decoration: none;
            color: #333;
        }
        footer .social-icons {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        footer .social-icons i{
            font-size: 40px; /* Adjust icon size */
        color: #333; /* Adjust icon color as needed */
        }

        table {
            border-collapse: separate;
            border-spacing: 20px; /* Space between images */
        }
        td {
            padding: 10px; /* Padding inside each cell */
        }
        table img {
            width: 150px; /* Adjust the size of the image */
            height: auto;
            border-radius: 50%;
        }
        .center{
            margin-left: auto;
            margin-right: auto;
        } 
    </style>
</head>
<body>

    <!-- Header -->
    <header>
        <div class="logo"><img src="logo.jpg" alt="MPSM Beverages"></div>
        <nav class="nav-menu" aria-label="Main Navigation" >
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php#products">Shop Now</a></li>
                <li><a href="#footer">Contact Us</a></li>
            </ul>
        </nav>
        <div class="icons">
            <div class="search-icon"><a href="search.php"><i class="fa-solid fa-magnifying-glass"></i></a></div>
            <div class="cart-icon"><a href="cartpage.php"><i class="fa-solid fa-cart-shopping"></i></a></div>
            <div class="profile-icon"><a href="profile.php"><i class="fa-solid fa-user"></i></a></div>
        </div>
    </header>
<main>
    <div class="form-container">
    <h1>Address</h1>

   
<!-- Form to update address -->
<form method="POST" action="update_address_action.php">
        <div class="form-group">
        <center><p class="warning">Change only the details you would like to update. Double-check the new address to ensure it is correct, as this will help avoid any issues with deliveries or communications.</p></center>
            <label for="phone">Phone</label>
            <input type="text" id="phone" name="phone" value="<?php echo $user['phone']; ?>" required>
        </div>
        <div class="form-group">
            <label for="street-address">Street Address</label>
            <input type="text" id="street-address" name="street-address" value="<?php echo $user['street_address']; ?>" required>
        </div>
        <div class="form-group">
            <label for="suburb">Suburb Address</label>
            <input type="text" id="suburb" name="suburb" value="<?php echo $user['suburb']; ?>" required>
        </div>
        <div class="form-group">
            <label for="city">City</label>
            <input type="text" id="city" name="city" value="<?php echo $user['city']; ?>" required>
        </div>
        <div class="form-group">
            <label for="province">Province</label>
            <input type="text" id="province" name="province" value="<?php echo $user['province']; ?>" required>
        </div>
        <div class="form-group">
            <label for="postal_code">Postal Code</label>
            <input type="text" id="postal_code" name="postal_code" value="<?php echo $user['postal_code']; ?>" required>
        </div>
        <div class="form-group">
            <button type="submit">Save Address</button>
        </div>
    </form>
</div>


</main>
<footer>
        <class="footer-container" id="footer">
        
        <div><u><center><h3>Contact Us</h3></center></u></div><br><br>

            <table class="center" border-spacing="100px">
                <tr>
                    <td>
                        
                            <p><strong>Physical Address:</strong></p>
                            <p>Innovation Worx Unit b15, Cnr 16th Road, Scale End,<br>
                            Halfway House Estate, Johannesburg, 1688</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Open Hours:</strong><br>
                                Mon-Fri: 9am-5pm<br>
                                    Sat: 9am-3pm<br>
                                    Sun: 9am-1pm</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Contact Information:</strong></p>
                            <p>Phone: 064 944 4905</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Quick Links:</strong></p>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="index.php#products">Shop Now</a></li>
                                <li><a href="https://wa.me/27649444905">Help</a></li>
                                <li><a href="cartpage.php">Cart</a></li>
                                <li><a href="profile.php">Profile</a></li>
                            </ul>
                        
                    </td>
                </tr>
            </table>
        <div class="social-icons">
            <a href="https://www.instagram.com/mpsm_water?igsh=MXcwcGliNXhtNG5uMA==" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://wa.me/27649444905"><i class="fa-brands fa-whatsapp" target="_blank"></i></a>
            <a href=https://www.facebook.com/profile.php?id=100075529239031&mibextid=LQQJ4d target="_blank"><i class="fa-brands fa-facebook"></i></a>
        </div><br><br>
        <p>&copy; 2024 MPSM Beverages. All Rights Reserved.</p>
    </footer>

</body>
</html>

