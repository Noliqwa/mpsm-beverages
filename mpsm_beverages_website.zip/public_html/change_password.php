<?php
// Start the session and include the database connection
session_start();
include('config.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve the form data
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm']);

    // Check if the new password and confirmation match
    if ($new_password !== $confirm_password) {
        echo "Passwords do not match!";
        exit();
    }

    // Check if the password meets certain security criteria (optional)
    if (strlen($new_password) < 8) {
        echo "Password must be at least 8 characters long!";
        exit();
    }

    // Hash the new password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Prepare the SQL statement to update the password
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashed_password, $user_id);

    // Execute the update query
    if ($stmt->execute()) {
        echo "Password updated successfully!";
        header("Location: changepassword.php?success=Password updated successfully");
        exit();
    } else {
        echo "Error updating password: " . $conn->error;
    }

    // Close the statement
    $stmt->close();
}
?>
