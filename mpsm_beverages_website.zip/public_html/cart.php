<?php
// Database connection setup
$host = "localhost";
$db_user = "bofsfkhe_mpsmecommerce";
$db_password = "PHPNRgUgRvuhJVuBR2De";
$db_name = "bofsfkhe_mpsmecommerce";
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";
try {
    $pdo = new PDO($dsn, $db_user, $db_password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}

header('Content-Type: application/json');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// Start the session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Initialize a response array
$response = ['success' => false, 'message' => 'An error occurred'];

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $response['message'] = 'User is not logged in';
    echo json_encode($response);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

// Check if action and required parameters are set
if (!$action) {
    $response['message'] = 'No action specified';
    echo json_encode($response);
    exit();
}

$userID = $_SESSION['user_id'];

// Handle add to cart action
if ($action === 'add') {
    $productID = $input['productID'] ?? null;
    $productName = $input['productName'] ?? null;
    $price = $input['Price'] ?? null;
    $quantity = $input['quantity'] ?? null;
    $imageURL = $input['imageURL'] ?? null;

    if (!$productID || !$productName || !$price || !$quantity || !$imageURL) {
        $response['message'] = 'Invalid product data';
        echo json_encode($response);
        exit();
    }

    try {
        // Check if item is already in cart
        $stmt = $pdo->prepare("SELECT * FROM cart WHERE userID = ? AND productID = ?");
        $stmt->execute([$userID, $productID]);
        $cartItem = $stmt->fetch();

        if ($cartItem) {
            // Update quantity if item exists in cart
            $newQuantity = $cartItem['quantity'] + $quantity;
            $updateStmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE cartID = ?");
            $updateStmt->execute([$newQuantity, $cartItem['cartID']]);
        } else {
            // Insert new item into cart
            $insertStmt = $pdo->prepare("INSERT INTO cart (userID, productID, productName, Price, quantity, imageURL) VALUES (?, ?, ?, ?, ?, ?)");
            $insertStmt->execute([$userID, $productID, $productName, $price, $quantity, $imageURL]);
        }

        // Set success response
        $response = ['success' => true, 'message' => 'Item added to cart'];
    } catch (PDOException $e) {
        $response['message'] = 'Database error: ' . $e->getMessage();
    }
}

// Handle update quantity action
if ($action === 'update') {
    $cartID = $input['cartID'] ?? null;
    $newQuantity = max(1, (int)($input['quantity'] ?? 0));

    if (!$cartID) {
        $response['message'] = 'Cart item ID missing';
    } else {
        try {
            $updateStmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE cartID = ?");
            if ($updateStmt->execute([$newQuantity, $cartID])) {
                $response = ['success' => true, 'message' => 'Item quantity updated'];
            }
        } catch (PDOException $e) {
            $response['message'] = 'Database error: ' . $e->getMessage();
        }
    }
}

// Handle delete item action
if ($action === 'delete') {
    $cartID = $input['cartID'] ?? null;

    if (!$cartID) {
        $response['message'] = 'Cart item ID missing';
    } else {
        try {
            $deleteStmt = $pdo->prepare("DELETE FROM cart WHERE cartID = ?");
            if ($deleteStmt->execute([$cartID])) {
                $response = ['success' => true, 'message' => 'Item deleted from cart'];
            }
        } catch (PDOException $e) {
            $response['message'] = 'Database error: ' . $e->getMessage();
        }
    }
}

// Return the final response as JSON
echo json_encode($response);
?>
