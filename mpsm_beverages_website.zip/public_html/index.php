<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['user_id']);

// Logout logic
if (isset($_GET['logout']) && $_GET['logout'] === 'true') {
    session_unset();
    session_destroy();
    header('Location: index.php');
    exit();
}

// Database Connection
$host = getenv('DB_HOST') ?: 'localhost';  
$db   = getenv('DB_NAME') ?: 'bofsfkhe_mpsmecommerce';  
$user = getenv('DB_USER') ?: 'bofsfkhe_mpsmecommerce';
$pass = getenv('DB_PASS') ?: 'PHPNRgUgRvuhJVuBR2De'; 
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage(), 3, 'error_log.txt');
    echo "We're experiencing technical difficulties. Please try again later.";
    exit;
}

// Juices Section
try {
    $query = "SELECT * FROM products WHERE Category = 'Juices'";
    $statement = $pdo->prepare($query);

    if ($statement->execute()) {
        $juices = $statement->fetchAll(PDO::FETCH_ASSOC);  
    } else {
        $juices = [];  
        echo "Query failed to execute.";
    }
} catch (PDOException $e) {
    die("Error retrieving data: " . $e->getMessage());
}

// Water Section
try {
    $query = "SELECT * FROM products WHERE Category = 'Water'";
    $statement = $pdo->prepare($query);

    if ($statement->execute()) {
        $water = $statement->fetchAll(PDO::FETCH_ASSOC);  
    } else {
        $water = [];  
        echo "Query failed to execute.";
    }
} catch (PDOException $e) {
    die("Error retrieving data: " . $e->getMessage());
}
//Ice Section
try {
    $query = "SELECT * FROM products WHERE Category = 'Ice'";
    $statement = $pdo->prepare($query);

    if ($statement->execute()) {
        $Ice = $statement->fetchAll(PDO::FETCH_ASSOC);  
    } else {
        $Ice = [];  
        echo "Query failed to execute.";
    }
} catch (PDOException $e) {
    die("Error retrieving data: " . $e->getMessage());
}
//Equipment section
try {
    $query = "SELECT * FROM products WHERE Category = 'Distillation Equipment'";
    $statement = $pdo->prepare($query);

    if ($statement->execute()) {
        $distillation_equipment = $statement->fetchAll(PDO::FETCH_ASSOC);  
    } else {
        $distillation_equipment = [];  
        echo "Query failed to execute.";
    }
} catch (PDOException $e) {
    die("Error retrieving data: " . $e->getMessage());
}
//Refills section
try {
    $query = "SELECT * FROM products WHERE Category = 'Refills'";
    $statement = $pdo->prepare($query);

    if ($statement->execute()) {
        $refills = $statement->fetchAll(PDO::FETCH_ASSOC);  
    } else {
        $refills = [];  
        echo "Query failed to execute.";
    }
} catch (PDOException $e) {
    die("Error retrieving data: " . $e->getMessage());
}
//Customisation
try {
    $query = "SELECT * FROM products WHERE Category = 'Customised Beverages'";
    $statement = $pdo->prepare($query);

    if ($statement->execute()) {
        $customised_bottles = $statement->fetchAll(PDO::FETCH_ASSOC);  
    } else {
        $customised_bottles= [];  
        echo "Query failed to execute.";
    }
} catch (PDOException $e) {
    die("Error retrieving data: " . $e->getMessage());
} 



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MPSM Beverages</title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f9f9f9;
}

/*----------------- Header styling ---------------*/
header {
    position: sticky;
    top: 0;
    background-color: #fff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

/* Logo styling */
header .logo img {
    width: 200px;
    height: auto; /* Maintain aspect ratio */
}

/* Navigation styling for larger screens */
header nav.nav-menu {
    flex-grow: 1;
    display: flex;
    justify-content: center; /* Center navigation */
}

header nav.nav-menu ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
    padding: 0;

}

header nav.nav-menu ul li a {
    text-decoration: none; /* Remove underline for nav links */
    color: #333;
    font-size: 20px;
    padding: 8px 12px;
    transition: color 0.3s ease;
    
}

header nav.nav-menu ul li a:hover {
    color: #fbb01b; /* Change link color on hover */
}

/* Icons container */
header .icons {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #333b;
    margin-right: 20px;
}

header .icons i {
    font-size: 24px;
    cursor: pointer;
    transition: color 0.3s ease;
    color: black;
    
}

header .icons i:hover {
    color: orange; /* Change icon color on hover */
}

/*---------Hover effect for the navigation----------------------------*/
.hover-effect {
    transition: transform 0.3s ease, opacity 0.3s ease; /* Smooth transition */
}

.hover-effect:hover {
    transform: scale(1.1); /* Scale the image slightly */
    opacity: 0.9; /* Slightly reduce opacity on hover */
}

/* Auth links */
.auth-links {
    display: flex;
    gap: 15px;
    align-items: center;
    margin-right: 15px; /* Adjusted margin */
    justify-content: center;
}

.auth-links ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;
}

.auth-links a {
    text-decoration: none; /* Ensure no underline */
    color: inherit;
    padding: 5px 10px;
    font-size: 16px;
    transition: color 0.3s ease;
}

.auth-links a:hover {
    color: #fbb01b; /* Change color on hover */
    text-decoration: underline;
}

/* Search bar styling */
.search-container {
    display: flex;
    align-items: center;
    gap: 5px;
    flex-grow: 1; /* Allow search to take up space */
    margin-right: 10px; /* Reduced spacing */
}

#search-input {
    padding: 5px;
    width: 180px;
}

#search-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
}

#search-btn i {
    font-size: 18px;
}

/* Media Queries for Responsiveness */
@media (max-width: 768px) {
    header {
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        padding: 10px;
    }

    /* Hide nav-menu on smaller screens */
    header nav.nav-menu {
        display: none;
    }

    /* Show menu icon on smaller screens */
    .menu-icon {
        display: flex;
        cursor: pointer;
        font-size: 24px;
    }

    .search-container {
        flex-grow: 1;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        margin-right: 5px;
    }

    #search-input {
        width: 100%; /* Full width on smaller screens */
    }

    header .logo img {
        width: 120px; /* Smaller logo on smaller screens */
    }

/* Overlay Menu Styles for smaller screens */
.overlay-menu {
    display: none; /* Hidden by default */
    position: fixed;
    top: 0;
    right: 0;
    width: 40%; /* Reduced overlay width */
    height: 100%;
    background-color: white; /* Background is white */
   /* background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */

    color: black; /* Font color is black */
    z-index: 1000;
    padding-top: 60px;
    padding-left: 20px; /* Add some padding on the left */
    transition: opacity 0.3s ease, visibility 0.3s ease; /* Smooth transition for opacity and visibility */
    opacity: 0; /* Start hidden */
    visibility: hidden; /* Avoid clicks when hidden */

}

/* Additional styling for links, if needed */
.overlay-menu a {
    color: black; /* Change link color to black */
    text-decoration: none; /* Remove underline from links */
    transition: color 0.3s ease; /* Smooth color transition */
    margin-top: 50px;
}

.overlay-menu a:hover {
    color: #fbb01b; /* Change link color on hover */
}

.overlay-menu.active {
    display: block; /* Show when active */
    opacity: 1; /* Fully opaque when active */
    visibility: visible; /* Allow clicks */
}

.overlay-menu ul {
    list-style-type: none;
    padding: 0;
}

.overlay-menu ul li {
    padding: 15px 20px;
    font-size: 20px;
    text-align: center;
}
/* Opptional: Add a transition for smoother appearance */
.overlay-menu {
    opacity: 0; /* Start hidden */
    visibility: hidden; /* Avoid clicks when hidden */
}

.overlay-menu.active {
    opacity: 1; /* Fade in effect */
    visibility: visible; /* Allow clicks */
}


    .close-icon {
        position: absolute;
        top: 20px;
        right: 20px;
        font-size: 30px;
        cursor: pointer;
    }
}

@media (min-width: 769px) {
    /* Hide overlay menu on larger screens */
    .overlay-menu {
        display: none;
    }

    /* Show horizontal nav-menu on larger screens */
    header nav.nav-menu {
        display: flex;
    }

    .menu-icon {
        display: none; /* Hide menu icon on larger screens */
    }
}
/*-------------------------------------------------Welcome message --------------------------------------*/
/* Notification Banner Styling */
.notification-banner {
    display: flex;
    align-items: center;
    justify-content: flex-end; /* Align icon and text to the right */
    padding: 15px 20px;
    background-color: #f8f9fa;
    border-bottom: 1px solid #e0e0e0;
    border-top: 1px solid #e0e0e0;
    color: #333;
    font-size: 1rem;
    font-family: Arial, sans-serif;
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
}

/* Specific Text Styles */
.welcome-message, .notification-message {
    font-weight: bold;
    margin: 0px;
}

/* Icon Styling */
.notification-banner i {
    color: orange; /* Orange color for visibility */
    font-size: 1.2rem;
    margin-left: 10px; /* Space between icon and text */
}
/* .hero-banner {
    width: 100%;
    height: 300px;
    background-color: #e1e1e1;
    margin-top: 20px;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
} */
.hero-banner {
    width: 100%;
    height: 300px;
    background-color: #e1e1e1;
    margin-top: 20px;
}
.img-hero{
    width: 100%;
    height: 300px;
    margin-top: 0px;
}

/*-------------------------------------------------Products Form --------------------------------------*/

.shop-by-category {
    text-align: center;
    margin: 20px 0;
    background-color: darkorange;
    padding: 15px; /* Added padding for better spacing */
    border-radius: 10px; /* Rounded corners */
    transition: background-color 0.3s ease; /* Smooth background transition */
}

.shop-by-category:hover {
    background-color: #ff8c00; /* Darker shade on hover */
}

.categories {
    display: flex;
    justify-content: center;
    gap: 30px;
    flex-wrap: wrap; /* Allows categories to wrap on smaller screens */
}

.categories div {
    width: 100px;
    height: 100px;  
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #ddd; /* Background color for visibility */
    transition: transform 0.3s ease; /* Smooth scaling effect */
}

.categories div:hover {
    transform: scale(1.1); /* Scale effect on hover */
}

        .products-section {
            width: 90%;
            margin: 0 auto;
        }
        .products-section h2 {
            margin-top: 20px;
        }
        .product-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            justify-content: flex-start;
        }
        .product-item {
            background-color: #fff;
            width: 250px;
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 10px;
        }
        .product-item img {
            width: 100%;
            height: 100;
            background-color: #ccc;
             /*transition: transform 0.3s ease;  Smooth transition for scaling */

        }

        .product-item p {
            margin: 10px 0;
        }
        .product-item select,
        .product-item button {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
            font-size: 14px;
        }
        .product-bottom {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .product-quantity {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .quantity-control {
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .quantity-control button {
        width: 25px;
        height: 25px;
        background-color: #ccc;
        border: none;
        cursor: pointer;
    }

    .quantity-control input {
        width: 50px;
        text-align: center;
    }

    .add-to-cart-btn {
        background-color: #fbb01b;
        color: white;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
    }

    .product-review a {
        color:#fbb01b;
        /*text-decoration: underline;*/
        cursor: pointer;
    }
        button {
            padding: 10px 20px;
            background-color: #fbb01b;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #ecb74d;
        }
       
        /* Style for the search container */
    .search-icon {
        position: relative;
        margin-left: -200px;
    }

    /* The search icon button */
    #search-icon-btn {
        background: none;
        border: none;
        cursor: pointer;
    /* margin-left: -100px;*/

    }

    /* Hidden search popup by default */
    .search-popup {
        display: none;
        position: absolute;
        top: 40px; 
        left: 0;
        background-color: white;
        padding: 10px;
        border: 1px solid #ccc;
        z-index: 1000;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    /* Input inside the popup */
    #search-input {
        padding: 5px;
        width: 200px;
    }

    /* Transition effect (optional) */
    .search-popup.show {
        display: block;
        animation: fadeIn 0.3s ease-in-out;
    }

    /* Optional fade-in effect */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    /* Product grid layout */
    .product-grid {
        display: flex;
        flex-wrap: wrap;
    }

    .product-item {
        width: 200px;
        margin: 10px;
        border: 1px solid #ccc;
        padding: 10px;
        text-align: center;
    }
    /*Search icon*/
        /* Lightbox styles */
    #lightbox {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.8);
        display: none;
        justify-content: center;
        align-items: center;
    }

    #lightbox img {
        max-width: 90%;
        max-height: 90%;
    }

    #lightbox:target {
        display: flex;
    }

    #lightbox .close {
        position: absolute;
        top: 20px;
        right: 40px;
        font-size: 40px;
        color: white;
        text-decoration: none;
        cursor: pointer;
    }
    a {
        text-decoration: none;
    }
    footer {
            background-color: #ff790e;
            padding: 20px;
            text-align: center;
            border-top: 1px solid #ddd;
            margin-top: 20px;
        }
        footer .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }
        footer .footer-container div {
            width: 50%;
        }
        footer .footer-container .quick-links ul {
            list-style: none;
            padding: 0;
        }
        footer .footer-container .quick-links ul li {
            margin: 5px 0;
        }
        footer .footer-container .quick-links ul li a {
            text-decoration: none;
            color: #333;
        }
        footer .social-icons {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        footer .social-icons i{
            font-size: 40px; /* Adjust icon size */
        color: #333; /* Adjust icon color as needed */
        }

        table {
            border-collapse: separate;
            border-spacing: 20px; /* Space between images */
        }
        td {
            padding: 10px; /* Padding inside each cell */
        }
        table img {
            width: 150px; /* Adjust the size of the image */
            height: auto;
            border-radius: 50%;
        }
        .center{
            margin-left: auto;
            margin-right: auto;
        } 

        /*************************Space at footer******************/
        .center {
        margin: 0 auto;
        border-collapse: separate;
        border-spacing: 50px; /* Adjust space between cells */
    }
    .center td {
        padding: 20px; /* Adjusts padding inside each cell */
        vertical-align: top;
    }

</style>
</head>


<body>

<!-- Header -->
<header>
    <div class="logo">
        <img src="logo.jpg" alt="Logo">
    </div>

    <nav class="nav-menu" aria-label="Main Navigation">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="index.php#products">Shop Now</a></li>
            <li><a href="#footer">Contact Us</a></li>
        </ul>
    </nav>

    <div class="icons" aria-label="Search Products"> 
        <a href="search.php"><i class="fa-solid fa-magnifying-glass"></i></a>
    </div>
   
    <div class="icons"> 
    <?php if ($isLoggedIn): ?>
        <div class="cart-icon">
            <a href="cartpage.php"><i class="fa-solid fa-cart-shopping"></i></a>
        </div>
        <div class="profile-icon">
            <a href="profile.php"><i class="fa-solid fa-user"></i></a>
        </div>
        <div class="logout-icon">
            <a href="index.php?logout=true"><i class="fa-solid fa-right-from-bracket"></i> </a>
        </div>
    <?php else: ?>
        <div class="auth-links">
            <ul>
                <li><a href="loginpage.php"><i class="fa-solid fa-right-to-bracket"></i> Login</a></li>
                <li><a href="registrationpage.php"><i class="fa-solid fa-user-plus"></i> Register</a></li>
            </ul>
        </div>
    <?php endif; ?>
</div>

<div class="menu-icon" aria-label="Menu" role="button" tabindex="0">
    <i class="fa-solid fa-bars"></i>
</div>
</header>

<!-- Include Font Awesome in your head section -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<nav class="overlay-menu nav-menu" aria-label="Main Navigation"> 
    <span class="close-icon" aria-label="Close Menu">&times;</span>
    <ul>
        <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
        <li><a href="index.php#products"><i class="fas fa-shopping-cart"></i> Shop Now</a></li>
        <li><a href="orders.php"><i class="fas fa-box"></i> Orders</a></li>
        <li><a href="#footer"><i class="fas fa-envelope"></i> Contact Us</a></li>
        <li><a href="profile.php"><i class="fa-solid fa-user"></i> Profile</a></li>
        <li><a href="loginpage.php"><i class="fa-solid fa-right-to-bracket"></i> Login</a></li>

    </ul>
</nav>

<!-- Display Notification or Welcome Message -->
<div class="notification-banner <?php echo $isLoggedIn ? 'logged-in' : 'guest'; ?>">
    <?php
    if ($isLoggedIn) {
        // Fetch the user's first name and last name
        $user_id = $_SESSION['user_id'];
        $stmt = $pdo->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        // Display welcome message if user data is found
        if ($user) {
            $first_name = $user['first_name'];
            $last_name = $user['last_name'];
            echo "<div class='welcome-message'><i class='fas fa-smile'></i> Welcome, $first_name $last_name!</div>";
        }
    } else {
        echo "<div class='notification-message'><i class='fas fa-bullhorn'></i> Please log in or register.</div>";
    }
    ?>
</div>


    <!-- Hero Banner -->
    <div class="hero-banner">
        <img class="img-hero "src="Mpsm Banner.png" alt="">
    </div>


    <!-- Shop by Category -->
    <div class="shop-by-category" id="shopnow">
        <h2 style="font-family: cursive">Shop by Category</h2>
    </div>
    
    <div>
    <table class="center"> 
    <tr>
        <td>
            <a href="#juice">
                <img src="msjuice.jpg" alt="Juices" class="hover-effect">
                <p style="font-family:cursive; text-align:center;">Juices</p>
            </a>
        </td>
        <td>
            <a href="#water">
                <img src="Water.jpg" alt="Water" class="hover-effect">
                <p style="font-family:cursive; text-align:center;">Water</p>
            </a>
        </td>
        <td>
            <a href="#ice">
                <img src="Ice.jpg" alt="Ice" class="hover-effect">
                <p style="font-family:cursive; text-align:center;">Ice</p>
            </a>
        </td>
        <td>
            <a href="#distillationequipment">
                <img src="distillation.jpg" alt="Equipment" class="hover-effect">
                <p style="font-family:cursive; text-align:center;">Equipment</p>
            </a>
        </td>
    </tr>
</table>

</div>


        <div class="container">
    <div class="products-section" id="search-popup">
        <h2 id="products"><center>Products</center></h2><br><br>
        <!-------------------Search Results------------------>
        <div id="search-results"></div>

<!-- Juices Section -->
<h2 id="juice">Juices</h2>
<div class="product-grid">
    <?php foreach ($juices as $juice): ?>
        <div class="product-item" data-name="<?= strtolower(str_replace(' ', '-', $juice['productName'])); ?>">
            <img src="<?= $juice['imageURL']; ?>" alt="<?= $juice['productName']; ?>">
            <div class="product-name"><?= $juice['productName']; ?> - <?= $juice['volume']; ?></div>
            <div class="product-price">R<?= number_format($juice['Price'], 2); ?></div>
            <div class="product-bottom">
                <div class="product-quantity">
                    <label for="qty-<?= strtolower($juice['SKU']); ?>">Quantity</label>
                    <div class="quantity-control">
                        <input type="number" id="qty-<?= strtolower($juice['SKU']); ?>" value="1" min="1" max="<?= $juice['stockLevel']; ?>">
                        <button class="increase-btn" onclick="increaseQuantity('qty-<?= strtolower($juice['SKU']); ?>')">+</button>
                        <button class="decrease-btn" onclick="decreaseQuantity('qty-<?= strtolower($juice['SKU']); ?>')">-</button>
                    </div>
                </div>
                <button class="add-to-cart-btn" onclick="addToCart(<?= $juice['ItemID']; ?>, '<?= $juice['productName']; ?>', <?= $juice['Price']; ?>, 'qty-<?= strtolower($juice['SKU']); ?>', '<?= $juice['imageURL']; ?>')">
                    Add to Cart
                </button>
                <div class="product-rating">0.0 rating</div>
                <div class="product-review">
                    <a href="review.php?products_ItemID=<?= $juice['ItemID']; ?>">Reviews</a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Water Section -->
<h2 id="water">Water</h2>
<div class="product-grid">
    <?php if (!empty($water)): ?>
        <?php foreach ($water as $item): ?>
            <div class="product-item" data-name="<?= strtolower(str_replace(' ', '-', $item['productName'])); ?>">
                <img src="<?= $item['imageURL']; ?>" alt="<?= $item['productName']; ?>">
                <div class="product-name"><?= $item['productName']; ?> - <?= $item['volume']; ?></div>
                <div class="product-price">R<?= number_format($item['Price'], 2); ?></div>
                <div class="product-bottom">
                    <div class="product-quantity">
                        <label for="qty-<?= strtolower($item['SKU']); ?>">Quantity</label>
                        <div class="quantity-control">
                            <input type="number" id="qty-<?= strtolower($item['SKU']); ?>" value="1" min="1" max="<?= $item['stockLevel']; ?>">
                            <button class="increase-btn" onclick="increaseQuantity('qty-<?= strtolower($item['SKU']); ?>')">+</button>
                            <button class="decrease-btn" onclick="decreaseQuantity('qty-<?= strtolower($item['SKU']); ?>')">-</button>
                        </div>
                    </div>
                    <button class="add-to-cart-btn" onclick="addToCart(<?= $item['ItemID']; ?>, '<?= $item['productName']; ?>', <?= $item['Price']; ?>, 'qty-<?= strtolower($item['SKU']); ?>', '<?= $item['imageURL']; ?>')">
                        Add to Cart
                    </button>
                    <div class="product-rating">0.0 rating</div>
                <div class="product-review">
                    <a href="review.php?products_ItemID=<?= $item['ItemID']; ?>">Reviews</a>
                </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No water products available at the moment.</p>
    <?php endif; ?>
</div>

<!-- Distillation Equipment Section -->
<h2 id="distillation-equipment">Distillation Equipment</h2>
<div class="product-grid">
    <?php if (!empty($distillation_equipment)): ?>
        <?php foreach ($distillation_equipment as $equipment): ?>
            <div class="product-item" data-name="<?= strtolower(str_replace(' ', '-', $equipment['productName'])); ?>">
                <img src="<?= $equipment['imageURL']; ?>" alt="<?= $equipment['productName']; ?>">
                <div class="product-name"><?= $equipment['productName']; ?> - <?= $equipment['volume']; ?></div>
                <div class="product-price">R<?= number_format($equipment['Price'], 2); ?></div>
                <div class="product-bottom">
                    <div class="product-quantity">
                        <label for="qty-<?= strtolower($equipment['SKU']); ?>">Quantity</label>
                        <div class="quantity-control">
                            <input type="number" id="qty-<?= strtolower($equipment['SKU']); ?>" value="1" min="1" max="<?= $equipment['stockLevel']; ?>">
                            <button class="increase-btn" onclick="increaseQuantity('qty-<?= strtolower($equipment['SKU']); ?>')">+</button>
                            <button class="decrease-btn" onclick="decreaseQuantity('qty-<?= strtolower($equipment['SKU']); ?>')">-</button>
                        </div>
                    </div>
                    <button class="add-to-cart-btn" onclick="addToCart(<?= $equipment['ItemID']; ?>, '<?= $equipment['productName']; ?>', <?= $equipment['Price']; ?>, 'qty-<?= strtolower($juice['SKU']); ?>', '<?= $equipment['imageURL']; ?>')">
                    Add to Cart
                    </button>
                </div>
                <div class="product-rating">0.0 rating</div>
                <div class="product-review">
                    <a href="review.php?products_ItemID=<?= $equipment['ItemID']; ?>">Reviews</a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No distillation equipment available at the moment.</p>
    <?php endif; ?>
</div>

<!-- Ice Section -->
<h2 id="ice">Ice</h2>
<div class="product-grid">
    <?php if (!empty($Ice)): ?>
        <?php foreach ($Ice as $ice_item): ?>
            <div class="product-item" data-name="<?= strtolower(str_replace(' ', '-', $ice_item['productName'])); ?>">
                <img src="<?= $ice_item['imageURL']; ?>" alt="<?= $ice_item['productName']; ?>">
                <div class="product-name"><?= $ice_item['productName']; ?> - <?= $ice_item['volume']; ?></div>
                <div class="product-price">R<?= number_format($ice_item['Price'], 2); ?></div>
                <div class="product-bottom">
                    <div class="product-quantity">
                        <label for="qty-<?= strtolower($ice_item['SKU']); ?>">Quantity</label>
                        <div class="quantity-control">
                            <input type="number" id="qty-<?= strtolower($ice_item['SKU']); ?>" value="1" min="1" max="<?= $ice_item['stockLevel']; ?>">
                            <button class="increase-btn" onclick="increaseQuantity('qty-<?= strtolower($ice_item['SKU']); ?>')">+</button>
                            <button class="decrease-btn" onclick="decreaseQuantity('qty-<?= strtolower($ice_item['SKU']); ?>')">-</button>
                        </div>
                    </div>
                    <button class="add-to-cart-btn" onclick="addToCart(<?= $ice_item['ItemID']; ?>, '<?= $ice_item['productName']; ?>', <?= $ice_item['Price']; ?>, 'qty-<?= strtolower($ice_item['SKU']); ?>', '<?= $ice_item['imageURL']; ?>')">
                    Add to Cart
                    </button>
                </div>
                <div class="product-rating">0.0 rating</div>
                <div class="product-review">
                    <a href="review.php?products_ItemID=<?= $ice_item['ItemID']; ?>">Reviews</a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No ice products available at the moment.</p>
    <?php endif; ?>
</div>


    <div class="service-section" id="search-popup">
        <h1 id="services"><center>Our Services</center></h1><br><br>

<!-- Refills Section -->
<h2 id="refills">Refills</h2>
<div class="product-grid">
    <?php if (!empty($refills)): ?>
        <?php foreach ($refills as $refill): ?>
            <div class="product-item" data-name="<?= strtolower(str_replace(' ', '-', $refill['productName'])); ?>">
                <img src="<?= $refill['imageURL']; ?>" alt="<?= $refill['productName']; ?>">
                <div class="product-name"><?= $refill['productName']; ?> - <?= $refill['volume']; ?></div>
                <div class="product-price">R<?= number_format($refill['Price'], 2); ?></div>
                <div class="product-bottom">
                   <p>Refill in Store, Not available online</p>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No refills available at the moment.</p>
    <?php endif; ?>
</div>

<!-- Customised Bottles Section -->
        <h2 id="refills">Customisation</h2>
          <div class="product-grid">
            <?php if (!empty($customised_bottles)): ?>
            <?php foreach ($customised_bottles as $customisation): ?>
            <div class="product-item" data-name="<?= strtolower(str_replace(' ', '-', $customisation['productName'])); ?>">
                <img src="<?= $customisation['imageURL']; ?>" alt="<?= $customisation['productName']; ?>">
                <div class="product-name"><?= $customisation['productName']; ?> - <?= $customisation['volume']; ?></div>
                <div class="product-bottom">
                </div>
            </div>
            <?php endforeach; ?>
            <?php else: ?>
                <p>No customised bottles.</p>
            <?php endif; ?>
</div>

<center><div><a href="https://wa.me/27649444905"><button id="button">Customise</button></a></div></center>

    <!-- Footer -->
    <footer>
        <class="footer-container" id="footer">
        
        <div><u><center><h3>Contact Us</h3></center></u></div><br><br>

            <table class="center" cell-padding="100px">
                <tr>
                    <td>
                        
                            <p><strong>Physical Address:</strong></p>
                            <p>Innovation Worx Unit b15, Cnr 16th Road, Scale End,<br>
                            Halfway House Estate, Johannesburg, 1688</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Open Hours:</strong><br>
                                Mon-Fri: 9am-5pm<br>
                                    Sat: 9am-3pm<br>
                                    Sun: 9am-1pm</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Contact Information:</strong></p>
                            <p>Phone: 064 944 4905</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Quick Links:</strong></p>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="index.php#products">Shop Now</a></li>
                                <li><a href="https://wa.me/27649444905">Help</a></li>
                                <li><a href="cartpage.php">Cart</a></li>
                                <li><a href="profile.php">Profile</a></li>
                            </ul>
                        
                    </td>
                </tr>
            </table>
        <div class="social-icons">
            <a href="https://www.instagram.com/mpsm_water?igsh=MXcwcGliNXhtNG5uMA==" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://wa.me/27649444905"target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
            <a href=https://www.facebook.com/profile.php?id=100075529239031&mibextid=LQQJ4d target="_blank"><i class="fa-brands fa-facebook"></i></a>
        </div><br><br>
        <p>&copy; 2024 MPSM Beverages. All Rights Reserved.</p>
    </footer>

   <!-- Lightbox for image popup -->
<div id="lightbox" onclick="closeLightbox()">
    <img id="lightbox-img" src="">
    <a href="javascript:void(0)" class="close" onclick="closeLightbox()">×</a>
</div>
    

</body>

<script>
// Check if user is logged in
const isLoggedIn = <?php echo json_encode(isset($_SESSION['user_id'])); ?>;

    // ----------------------------------------
    // Add to Cart Functionality
    // ----------------------------------------

    function addToCart(productId, productName, price, quantityId, imageURL) {
    const quantity = document.getElementById(quantityId).value;

    if (!isLoggedIn) {
        alert("Please log in to add items to your cart.");
        return;
    }

    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'add',
            productID: productId,
            productName: productName,
            Price: price,
            quantity: quantity,
            imageURL: imageURL
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log("Response Data:", data); // Debugging line
        if (data.success) {
            alert("Item added to cart!");
        } else {
            alert("Failed to add item.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("An error occurred while adding the item to the cart.");
    });
}


// Functions to increase/decrease quantity
function increaseQuantity(quantityId) {
    const quantityInput = document.getElementById(quantityId);
    quantityInput.value = parseInt(quantityInput.value) + 1;
}

function decreaseQuantity(quantityId) {
    const quantityInput = document.getElementById(quantityId);
    if (quantityInput.value > 1) {
        quantityInput.value = parseInt(quantityInput.value) - 1;
    }
}
</script>

<script>

    // ----------------------------------------
    // Overlay Menu for Mobile Navigation
    // ----------------------------------------

    const menuIcon = document.querySelector(".menu-icon");
    const overlayMenu = document.querySelector(".overlay-menu");
    const closeIcon = document.querySelector(".close-icon");

    // Toggle menu on mobile
    menuIcon.addEventListener("click", function() {
        overlayMenu.classList.toggle("active");
    });

    closeIcon.addEventListener("click", function() {
        overlayMenu.classList.remove("active");
    });

</script>
</html>