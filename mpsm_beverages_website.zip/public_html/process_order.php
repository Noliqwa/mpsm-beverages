<?php
session_start();
include 'config.php'; // Ensure database connection is included

// Get JSON data from request
$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'];
$name = $input['name'];
$surname = $input['surname'];
$deliveryOption = $input['deliveryOption'];
$address = $input['address'] ?? null; // Only for delivery
$products = $input['products'];

// Process payment (code omitted for simplicity, assuming it's already successful)

// Generate unique order number
$orderNumber = uniqid("ORD");

// Store order in database
try {
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, order_number, first_name, last_name, delivery_option, address, created_at, status) 
                           VALUES (?, ?, ?, ?, ?, ?, NOW(), 'Confirmed')");
    $stmt->execute([$_SESSION['user_id'], $orderNumber, $name, $surname, $deliveryOption, $address]);

    // Get the last inserted order ID
    $orderId = $pdo->lastInsertId();

    // Insert each product into order_items
    foreach ($products as $product) {
        $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_name, quantity, price) VALUES (?, ?, ?, ?)");
        $stmt->execute([$orderId, $product['productName'], $product['quantity'], $product['Price']]);
    }

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
