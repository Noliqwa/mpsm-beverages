<?php 
include_once('config.php');  // Database connection setup

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Enable error logging and report all errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Custom error handler to log errors
if (!function_exists('handleError')) {
    function handleError($errno, $errstr, $errfile, $errline) {
        $error_message = "Error [$errno] in $errfile at line $errline: $errstr";
        // Log the error to a log file or to an error tracking system
        error_log($error_message);
        exit();
    }
}
set_error_handler("handleError");

// Check if database connection is valid
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Database connection failed: " . mysqli_connect_error());
    exit();
}

// Attempt to call stored procedure 'get_notifications'
try {
    if ($conn->multi_query("CALL get_notifications()")) {
        // Process results if any returned by the procedure
        do {
            if ($result = $conn->store_result()) {
                while ($row = $result->fetch_assoc()) {
                    // Log each row from the result (optional)
                    error_log("Procedure row: " . json_encode($row));
                }
                $result->free();
            }
        } while ($conn->more_results() && $conn->next_result());
    } else {
        throw new Exception("Failed to call 'get_notifications': " . $conn->error);
    }
} catch (Exception $e) {
    error_log($e->getMessage());
    exit();
}

// Fetch unread notification count from database
$query = "SELECT COUNT(*) AS notification_count FROM notifications WHERE is_read = 0";
if ($result = $conn->query($query)) {
    $row = $result->fetch_assoc();
    $_SESSION['notification_count'] = $row['notification_count'];
} else {
    $_SESSION['notification_count'] = 0;
    error_log("Failed to fetch notification count: " . $conn->error);
    exit();
}

// Include additional notifications file, if exists
try {
    include_once 'fetch_notifications.php';
} catch (Exception $e) {
    error_log("Error including fetch_notifications.php: " . $e->getMessage());
    exit();
}
?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

 <style>  
/* Sidebar */
.sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background: white;
    color: black;
    padding-top: 20px;
}

.sidebar .profile {
    text-align: center;
    margin-bottom: 20px;
}

.sidebar .profile img {
    width: 100px;
    height: 100px;
    border: 2px solid white;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    position: relative;
    padding: 12px;
}

.sidebar ul li a {
    color: black;
    text-decoration: none;
    font-size: 16px;
    display: flex;
    align-items: center;
    padding: 8px;
    transition: background 0.3s, border-radius 0.3s;
    border-radius: 50px;
}

.sidebar ul li a i {
    margin-right: 10px;
}

.sidebar ul li a:hover {
    background-color: rgba(200, 200, 200, 0.6);
    cursor: pointer;
}

.sub-menu {
    display: none;
    position: absolute;
    left: 100%;
    top: 0;
    background: white;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    z-index: 1;
}

.sidebar ul li:hover .sub-menu {
    display: block;
}

.sub-menu li {
    padding: 10px;
}

.sub-menu li a {
    color: black;
    text-decoration: none;
    display: block;
    border-radius: 5px;
}

.sub-menu li a:hover {
    background-color: rgba(255, 165, 0, 0.3);
}

/* Top Navigation Bar */
nav {
    background: white;
    color: black;
    padding: 10px;
    position: fixed;
    width: calc(100% - 250px);
    left: 250px;
    top: 0;
    z-index: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nav-left {
    display: flex;
    align-items: center;
    position: relative; /* Needed for suggestions positioning */
}

.nav-right {
    display: flex;
    align-items: center;
}

.search-bar {
    padding: 8px;
    border-radius: 20px;
    border: 1px solid #ccc;
    outline: none;
    width: 200px;
    margin-right: 10px;
}

.nav-right i,
.nav-left i {
    color: black;
    font-size: 24px;
    margin-left: 10px;
    cursor: pointer;
    transition: color 0.3s;
}

.nav-right i:hover,
.nav-left i:hover {
    color: #2980b9;
}

.notification-badge {
    position: absolute;
    top: -8px;
    right: -8px;
    background-color: red;
    color: white;
    border-radius: 50%;
    padding: 3px 7px;
    font-size: 12px;
}

/* Footer */
footer {
    width: 100%;
    text-align: center;
    padding: 10px;
    background-color: #333;
    color: white;
    font-size: 14px;
    opacity: 0;
    transition: opacity 0.5s;
}

.footer-visible {
    opacity: 1;
}

/* Suggestions Dropdown */
.suggestions-list {
    display: none;
    position: absolute;
    top: 35px;
    left: 0;
    background-color: white;
    border: 1px solid #ccc;
    border-radius: 4px;
    width: 200px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    max-height: 200px;
    overflow-y: auto;
    z-index: 999;
}

.suggestions-list li {
    padding: 8px;
    cursor: pointer;
    font-size: 14px;
    color: #333;
}

.suggestions-list li:hover {
    background-color: #f0f0f0;
}

.suggestions-list a {
    text-decoration: none;
    color: #333;
    display: block;
}

.suggestions-list.empty {
    display: none;
}
</style>
 
</head>

<body>

<div class="sidebar">
    <div class="profile">
        <img src="logo.jpg" alt="Profile Picture">
        <h3>Welcome Administrator</h3>
    </div>
    <ul>
        <li>
            <a href="dashboard.php" class="main-item">
                <i class="fas fa-tachometer-alt"></i> Dashboard <i class="fas fa-chevron-down"></i>
            </a>
            
        </li>
        <li>
            <a href="products.php" class="main-item">
                <i class="fas fa-archive"></i> Inventory <i class="fas fa-chevron-down"></i>
            </a>
            
        </li>
        <li>
            <a href="ordermanagement.php" class="main-item">
                <i class="fas fa-receipt"></i> Orders <i class="fas fa-chevron-down"></i>
            </a>
            
        </li>
        <li>
            <a href="reviews.php" class="main-item">
                <i class="fas fa-file-invoice"></i> Customer Reviews <i class="fas fa-chevron-down"></i>
            </a>
            
        </li>
        <li>
            <a href="Analytics.php" class="main-item">
                <i class="fas fa-chart-line"></i> Reporting <i class="fas fa-chevron-down"></i>
            </a>
            
        </li>
        <li>
            <a href="supportpage.php" class="main-item">
                <i class="fas fa-question-circle"></i> Support <i class="fas fa-chevron-down"></i>
            </a>
           
        </li>
        <li>
            <a href="customer_management.php" class="main-item">
                <i class="fas fa-cog"></i> Customer Management <i class="fas fa-chevron-down"></i>
            </a>
           
        </li>
    </ul>
</div>
<nav> 
    <div class="nav-left">
        <i class="fas fa-search"></i>
        <input type="text" class="search-bar" id="searchBar" placeholder="Search..." oninput="showSuggestions()" autocomplete="off">
        <ul id="suggestionsList" class="suggestions-list"></ul> <!-- Dropdown list for suggestions -->
        <a href="registrationpage.php">
            <i class="fas fa-user" id="profileIcon"></i> <!-- Profile icon -->
        </a>
        <i class="fas fa-cog"></i> <!-- Settings icon -->
        <a href="notifications.php">
            <i class="fas fa-bell" id="notificationIcon"></i>
            <span class="notification-badge" id="notificationCount">
                <?php echo isset($_SESSION['notification_count']) ? htmlspecialchars($_SESSION['notification_count']) : '0'; ?>
            </span> <!-- Display notification count -->
        </a>
    </div>
</nav>


<script>
// Object of predefined search actions and their corresponding URLs
const suggestions = [
    { action: "Add Product", url: "products.php" },
    { action: "Delete Customer", url: "customermanagement.php" },
    { action: "View Orders", url: "ordersmanagement.php" },
    { action: "Manage Inventory", url: "ordersmanagement.php" },
    { action: "Search Customer", url: "customermanagement.php" },
    { action: "Update Product", url: "products.php" },
    { action: "Add Category", url: "products.php" },
    { action: "View Report", url: "see report.php" }
];

// Function to show suggestions as the user types
function showSuggestions() {
    const searchBar = document.getElementById('searchBar');
    const suggestionsList = document.getElementById('suggestionsList');
    const inputText = searchBar.value.toLowerCase();

    // Clear previous suggestions
    suggestionsList.innerHTML = "";

    // If input is not empty, show suggestions
    if (inputText !== "") {
        const filteredSuggestions = suggestions.filter(suggestion => 
            suggestion.action.toLowerCase().includes(inputText)
        );

        // If there are suggestions, display them
        if (filteredSuggestions.length > 0) {
            suggestionsList.style.display = 'block'; // Show the dropdown

            filteredSuggestions.forEach(suggestion => {
                const listItem = document.createElement('li');

                // Create an anchor element for the link
                const link = document.createElement('a');
                link.href = suggestion.url;
                link.textContent = suggestion.action;

                listItem.appendChild(link);
                suggestionsList.appendChild(listItem);
            });
        } else {
            suggestionsList.style.display = 'none'; // Hide if no matching suggestions
        }
    } else {
        suggestionsList.style.display = 'none'; // Hide if input is empty
    }
}

// Hide the suggestions when clicking outside
document.addEventListener('click', function(event) {
    const suggestionsList = document.getElementById('suggestionsList');
    const searchBar = document.getElementById('searchBar');
    
    if (!searchBar.contains(event.target)) {
        suggestionsList.style.display = 'none'; // Hide suggestions if clicked outside
    }
});

</script>


</body>
</html>