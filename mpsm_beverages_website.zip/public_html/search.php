<?php
// Database connection
$host = 'localhost';
$db = 'bofsfkhe_mpsmecommerce';
$user = 'bofsfkhe_mpsmecommerce';
$pass = 'PHPNRgUgRvuhJVuBR2De';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['user_id']);


// Retrieve the search query from the URL parameter
$query = isset($_GET['query']) ? strtolower(trim($_GET['query'])) : '';
$juices = []; // Initialize as an empty array

// Check if there is a search query before executing the query
if (!empty($query)) {
    // Prepare and execute SQL query to fetch matching products
    $sql = "SELECT * FROM products WHERE LOWER(productName) LIKE :query OR LOWER(category) LIKE :query";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['query' => "%$query%"]);

    // Fetch matching products
    $juices = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        header {
    position: sticky;
    top: 0;
    background-color: #fff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

/* Logo styling */
header .logo img {
    width: 200px;
    height: auto; /* Maintain aspect ratio */
}

/* Navigation styling for larger screens */
header nav.nav-menu {
    flex-grow: 1;
    display: flex;
    justify-content: center; /* Center navigation */
}

header nav.nav-menu ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
    padding: 0;

}

header nav.nav-menu ul li a {
    text-decoration: none; /* Remove underline for nav links */
    color: #333;
    font-size: 20px;
    padding: 8px 12px;
    transition: color 0.3s ease;
    
}

header nav.nav-menu ul li a:hover {
    color: #fbb01b; /* Change link color on hover */
}

/* Icons container */
header .icons {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #333b;
    margin-right: 20px;
}

header .icons i {
    font-size: 24px;
    cursor: pointer;
    transition: color 0.3s ease;
    color: black;
    
}

header .icons i:hover {
    color: orange; /* Change icon color on hover */
}


        #search-input {
            width: 50%;
            padding: 10px;
            font-size: 16px;
            margin-bottom: 20px;
            display: block;
            margin-left: auto;
            margin-right: auto;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .product-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            justify-content: flex-start;
        }
        .product-item {
            background-color: #fff;
            width: 250px;
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 10px;
        }
        .product-item img {
            width: 100%;
            height: 100;
            background-color: #ccc;
        }
        .product-item p {
            margin: 10px 0;
        }
        .product-item select,
        .product-item button {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
            font-size: 14px;
        }
        .product-bottom {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .product-quantity {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .quantity-control {
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .quantity-control button {
        width: 25px;
        height: 25px;
        background-color: #ccc;
        border: none;
        cursor: pointer;
    }

    .quantity-control input {
        width: 50px;
        text-align: center;
    }

    .add-to-cart-btn {
        background-color: #fbb01b;
        color: white;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
    }

    .product-review a {
        color:#fbb01b;
        text-decoration: underline;
        cursor: pointer;
    }
    a {
        text-decoration: none;
    }
    footer {
            background-color: #ff790e;
            padding: 20px;
            text-align: center;
            border-top: 1px solid #ddd;
            margin-top: 20px;
        }
        footer .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }
        footer .footer-container div {
            width: 50%;
        }
        footer .footer-container .quick-links ul {
            list-style: none;
            padding: 0;
        }
        footer .footer-container .quick-links ul li {
            margin: 5px 0;
        }
        footer .footer-container .quick-links ul li a {
            text-decoration: none;
            color: #333;
        }
        footer .social-icons {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        footer .social-icons i{
            font-size: 40px; /* Adjust icon size */
        color: #333; /* Adjust icon color as needed */
        }

    </style>
</head>
<body>
<!-- Header -->
<header>
    <div class="logo">
        <img src="logo.jpg" alt="Logo">
    </div>

    <nav class="nav-menu" aria-label="Main Navigation">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="index.php#products">Shop Now</a></li>
            <li><a href="#footer">Contact Us</a></li>
        </ul>
    </nav>
   
    <div class="icons"> 
    <?php if ($isLoggedIn): ?>
        <div class="cart-icon">
            <a href="cartpage.php"><i class="fa-solid fa-cart-shopping"></i></a>
        </div>
        <div class="profile-icon">
            <a href="profile.php"><i class="fa-solid fa-user"></i></a>
        </div>
        <div class="logout-icon">
            <a href="index.php?logout=true"><i class="fa-solid fa-right-from-bracket"></i> </a>
        </div>
    <?php else: ?>
        <div class="auth-links">
            <ul>
                <li><a href="loginpage.php"><i class="fa-solid fa-right-to-bracket"></i> Login</a></li>
                <li><a href="registrationpage.php"><i class="fa-solid fa-user-plus"></i> Register</a></li>
            </ul>
        </div>
    <?php endif; ?>
</div>
</header>
<div>
 <h1> <a href="index.php"><i class="fa-solid fa-arrow-left"></i></i></a> Search Results for: "<?php echo htmlspecialchars($query); ?>"</h1>

 <!-- Search form with JavaScript for real-time filtering -->
 <div class="search-bar">
    <form onsubmit="event.preventDefault();"> <!-- Prevent form from submitting -->
        <input 
            type="text" 
            id="searchInput" 
            placeholder="Search for products..." 
            autocomplete="off" 
            value="<?php echo htmlspecialchars($query); ?>" 
            oninput="updateSearchResults(this.value)">
    </form>
 </div>

 <!-- Product grid to display search results -->
 <div class="product-grid" id="productGrid">
    <?php if (empty($query)): ?>
        <p>Searched products will appear here.</p>
    <?php elseif (!empty($juices)): ?>
        <?php foreach ($juices as $juice): ?>
            <div class="product-item" data-name="<?= strtolower(str_replace(' ', '-', $juice['productName'])); ?>">
                <img src="<?= $juice['imageURL']; ?>" alt="<?= $juice['productName']; ?>">
                <div class="product-name"><?= $juice['productName']; ?> - <?= $juice['volume']; ?></div>
                <div class="product-price">R<?= number_format($juice['Price'], 2); ?></div>
                <div class="product-bottom">
                    <div class="product-cap-type">
                        <label for="cap-type-<?= strtolower($juice['SKU']); ?>">Type of cap</label>
                        <select id="cap-type-<?= strtolower($juice['SKU']); ?>">
                            <option><?= $juice['type_of_cap']; ?></option>
                        </select>
                    </div>
                    <div class="product-quantity">
                        <label for="qty-<?= strtolower($juice['SKU']); ?>">Quantity</label>
                        <div class="quantity-control">
                            <input type="number" id="qty-<?= strtolower($juice['SKU']); ?>" value="1" min="1" max="<?= $juice['stockLevel']; ?>">
                            <button class="increase-btn" onclick="increaseQuantity('qty-<?= strtolower($juice['SKU']); ?>')">+</button>
                            <button class="decrease-btn" onclick="decreaseQuantity('qty-<?= strtolower($juice['SKU']); ?>')">-</button>
                        </div>
                    </div>
                    <button class="add-to-cart-btn" onclick="addToCart(<?= $juice['ItemID']; ?>, '<?= $juice['productName']; ?>', <?= $juice['Price']; ?>, 'qty-<?= strtolower($juice['SKU']); ?>', '<?= $juice['imageURL']; ?>')">
                    Add to Cart
                    </button>
                </div>
                <div class="product-rating">0.0 rating</div>
                <div class="product-review">
                    <a href="review.php">Reviews</a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No products found for "<?php echo htmlspecialchars($query); ?>".</p>
    <?php endif; ?>
 </div>
</div>
<footer>
        <class="footer-container" id="footer">
        
        <div><u><center><h3>Contact Us</h3></center></u></div><br><br>

            <table class="center" cell-padding="100px">
                <tr>
                    <td>
                        
                            <p><strong>Physical Address:</strong></p>
                            <p>Innovation Worx Unit b15, Cnr 16th Road, Scale End,<br>
                            Halfway House Estate, Johannesburg, 1688</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Open Hours:</strong><br>
                                Mon-Fri: 9am-5pm<br>
                                    Sat: 9am-3pm<br>
                                    Sun: 9am-1pm</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Contact Information:</strong></p>
                            <p>Phone: 064 944 4905</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Quick Links:</strong></p>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="index.php#products">Shop Now</a></li>
                                <li><a href="https://wa.me/27649444905">Help</a></li>
                                <li><a href="cartpage.php">Cart</a></li>
                                <li><a href="profile.php">Profile</a></li>
                            </ul>
                        
                    </td>
                </tr>
            </table>
        <div class="social-icons">
            <a href="https://www.instagram.com/mpsm_water?igsh=MXcwcGliNXhtNG5uMA==" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://wa.me/27649444905"target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
            <a href=https://www.facebook.com/profile.php?id=100075529239031&mibextid=LQQJ4d target="_blank"><i class="fa-brands fa-facebook"></i></a>
        </div><br><br>
        <p>&copy; 2024 MPSM Beverages. All Rights Reserved.</p>
    </footer>


<script>
    let typingTimer;
const typingDelay = 1000; // Delay in milliseconds

function updateSearchResults(query) {
    clearTimeout(typingTimer); // Clear any previous timer
    typingTimer = setTimeout(() => {
        const url = new URL(window.location.href);
        url.searchParams.set('query', query);
        
        // Trigger reload after setting the updated URL with the new query
        window.location.href = url;
    }, typingDelay);
}


</script>
<script>
// Check if user is logged in
const isLoggedIn = <?php echo json_encode(isset($_SESSION['user_id'])); ?>;

    // ----------------------------------------
    // Add to Cart Functionality
    // ----------------------------------------

    function addToCart(productId, productName, price, quantityId, imageURL) {
    const quantity = document.getElementById(quantityId).value;

    if (!isLoggedIn) {
        alert("Please log in to add items to your cart.");
        return;
    }

    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'add',
            productID: productId,
            productName: productName,
            Price: price,
            quantity: quantity,
            imageURL: imageURL
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log("Response Data:", data); // Debugging line
        if (data.success) {
            alert("Item added to cart!");
        } else {
            alert("Failed to add item.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("An error occurred while adding the item to the cart.");
    });
}

// Functions to increase/decrease quantity
function increaseQuantity(quantityId) {
    const quantityInput = document.getElementById(quantityId);
    quantityInput.value = parseInt(quantityInput.value) + 1;
}

function decreaseQuantity(quantityId) {
    const quantityInput = document.getElementById(quantityId);
    if (quantityInput.value > 1) {
        quantityInput.value = parseInt(quantityInput.value) - 1;
    }
}

</script>
</body>
</html>
