<?php
session_start();

$host = "localhost";
$db_user = "bofsfkhe_mpsmecommerce";
$db_password = "PHPNRgUgRvuhJVuBR2De";
$db_name = "bofsfkhe_mpsmecommerce";
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";
try {
    $pdo = new PDO($dsn, $db_user, $db_password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}

$userID = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT COUNT(*) AS itemCount FROM cart WHERE userID = ?");
$stmt->execute([$userID]);
$count = $stmt->fetchColumn();

echo json_encode(['count' => $count]);
?>
