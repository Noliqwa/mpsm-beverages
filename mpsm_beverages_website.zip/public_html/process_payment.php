<?php
// process_payment.php
$secret_key = 'sk_live_c09ee7e4mpNYz8nac134355a0dbe';
$token = $_POST['token'];
$amount = 5000;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://online.yoco.com/v1/charges/");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'token' => $token,
    'amountInCents' => $amount,
    'currency' => 'ZAR'
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-Auth-Secret-Key: ' . $secret_key,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
curl_close($ch);

if ($response) {
    $result = json_decode($response, true);
    if (isset($result['status']) && $result['status'] === 'successful') {
        echo "Payment completed!";
    } else {
        echo "Payment failed.";
    }
} else {
    echo "Error processing payment.";
}
?>
