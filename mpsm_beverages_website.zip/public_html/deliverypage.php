<?php
session_start();

if (isset($_GET['subtotal'])) {
    $subtotal = floatval($_GET['subtotal']); // Convert to float for security
} else {
    $subtotal = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://js.yoco.com/sdk/v1/yoco-sdk-web.js"></script>
    <title>Delivery</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4; 
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-weight: bold;
        }

        h1 {
            font-size: 32px;
        }

        h2 {
            font-size: 24px;
            margin-bottom: 30px;
        }


        .radio-group {
            display: flex;
            justify-content: space-around;
            margin-bottom: 30px;
        }

        .radio-group label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .radio-group img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        input, textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }

        input:focus, textarea:focus {
            border-color: #333;
            outline: none;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
        }

        button {
            background-color: orange;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 15px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        button:hover {
           background-color: #ecb74d;
        }


    
        .delivery-fields, .collection-fields {
            display: none;
        }


        /*----------------- Header styling ---------------*/
header {
    position: sticky;
    top: 0;
    background-color: #fff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

/* Logo styling */
header .logo img {
    width: 200px;
    height: auto; /* Maintain aspect ratio */
}

/* Navigation styling for larger screens */
header nav.nav-menu {
    flex-grow: 1;
    display: flex;
    justify-content: center; /* Center navigation */
}

header nav.nav-menu ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
    padding: 0;

}

header nav.nav-menu ul li a {
    text-decoration: none; /* Remove underline for nav links */
    color: #333;
    font-size: 20px;
    padding: 8px 12px;
    transition: color 0.3s ease;
    
}

header nav.nav-menu ul li a:hover {
    color: #fbb01b; /* Change link color on hover */
}

/* Icons container */
header .icons {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #333b;
    margin-right: 20px;
}

header .icons i {
    font-size: 24px;
    cursor: pointer;
    transition: color 0.3s ease;
    color: black;
    
}

header .icons i:hover {
    color: orange; /* Change icon color on hover */
}

/*---------Hover effect for the navigation----------------------------*/
.hover-effect {
    transition: transform 0.3s ease, opacity 0.3s ease; /* Smooth transition */
}

.hover-effect:hover {
    transform: scale(1.1); /* Scale the image slightly */
    opacity: 0.9; /* Slightly reduce opacity on hover */
}

/* Auth links */
.auth-links {
    display: flex;
    gap: 15px;
    align-items: center;
    margin-right: 15px; /* Adjusted margin */
    justify-content: center;
}

.auth-links ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;
}

.auth-links a {
    text-decoration: none; /* Ensure no underline */
    color: inherit;
    padding: 5px 10px;
    font-size: 16px;
    transition: color 0.3s ease;
}

.auth-links a:hover {
    color: #fbb01b; /* Change color on hover */
    text-decoration: underline;
}

/* Search bar styling */
.search-container {
    display: flex;
    align-items: center;
    gap: 5px;
    flex-grow: 1; /* Allow search to take up space */
    margin-right: 10px; /* Reduced spacing */
}

#search-input {
    padding: 5px;
    width: 180px;
}

#search-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
}

#search-btn i {
    font-size: 18px;
}
a {
        text-decoration: none;
    }

        footer {
           background-color:#ff790e;
            color:#000000;
            padding: 20px;
            text-align: center;
            border-top: 1px solid #ddd;
            margin-top: 20px;
        }
        footer .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }
        footer .footer-container div {
            width: 30%;
        }
        footer .footer-container .quick-links ul {
            list-style: none;
            padding: 0;
        }
        footer .footer-container .quick-links ul li {
            margin: 5px 0;
        }
        #footer .footer-container .quick-links ul li a {
            text-decoration: none;
            color: #fbb01b;
        }
        footer .social-icons {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        footer .social-icons img {
            width: 40px;
            height: 40px;
        }

        table {
            border-collapse: separate;
            border-spacing: 20px; 
        }
        td {
            padding: 10px; 
        }
        table img {
            width: 150px; 
            height: auto;
            border-radius: 50%;
        }
        .center{
            margin-left: auto;
            margin-right: auto;
        }

        footer .social-icons {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        footer .social-icons i{
            font-size: 40px; /* Adjust icon size */
        color: #333; /* Adjust icon color as needed */
        }

        .savedaddress{
            margin-left: auto;
            margin-right: auto;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <!-- Header -->
    <header>
        <div class="logo"><img src="logo.jpg" alt="MPSM Beverages"></div>
        <nav class="nav-menu" aria-label="Main Navigation" >
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php#products">Shop Now</a></li>
                <li><a href="#footer">Contact Us</a></li>
            </ul>
        </nav>
        <div class="icons">
            <div class="search-icon"><a href="search.php"><i class="fa-solid fa-magnifying-glass"></i></a></div>
            <div class="cart-icon"><a href="cartpage.php"><i class="fa-solid fa-cart-shopping"></i></a></div>
            <div class="profile-icon"><a href="profile.php"><i class="fa-solid fa-user"></i></a></div>
        </div>
    </header>
    

    <div class="container">
        <h2>Select how you would like to receive your order</h2>
        

        <div class="radio-group">
            <label>
                <input type="radio" name="delivery-option" value="address">
                Delivery to address
                <i class="fa-solid fa-truck"></i>
            </label>
            <label>
                <input type="radio" name="delivery-option" value="pickup">
                Pick up
                <i class="fa-solid fa-store"></i>
            </label>
        </div>

        <!-- Delivery Fields -->
        <div class="delivery-fields">
        <center><h3>We Only Deliver In Gauteng</h3></center>
        <center><h3>R120 will be added for delivery fee</h3></center>
        <center><button class="savedaddress" onclick="useSavedAddress()">Use Saved Address</button></center><br><br>
            <form action="configlogin.php" method="POST">
                <input type="text" id="phone" name="phone" placeholder="Phone" required>
                <input type="text" id="street_address" name="street_address" placeholder="Street Address" required>
                <input type="text" id="suburb_address" name="suburb_address" placeholder="Suburb Address" required>
                <input type="text" id="city" name="city" placeholder="City" required>
                <input type="text" id="province" name="province" placeholder="Province" required>
                <input type="text" id="postalcode" name="postalcode" placeholder="Postal Code" required>
                <textarea id="notes" name="notes" placeholder="Additional Notes"></textarea> 

            </form>
        </div>

        <!-- Collection Fields -->
        <div class="collection-fields">
        <form action="process_delivery.php" method="POST">
            <input type="text" id="name" name="name" placeholder="Name" required>
            <input type="text" id="surname" name="surname" placeholder="Surname" required>
            <input type="text" id="phone" name="phone" placeholder="Phone" required>
            <input type="text" id="email" name="email" placeholder="Email" required>
            <input type="text" id="promo" name="promo" placeholder="Promo Code" required>
            <textarea id="notes" name="notes" placeholder="Additional Notes"></textarea>
            <h3>Store Location</h3>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1793.1875627028126!2d28.1284115!3d-25.988526399999987!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e956fd73c6622b5%3A0xb65c8c1164b1f8df!2sLeogem%20Innovation%20Worx%20Midrand!5e0!3m2!1sen!2sza!4v1728919502824!5m2!1sen!2sza" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </form>
        </div>
             <!-- Total Price Display -->
        <h3 id="totalDisplay">Total: R<?php echo number_format($subtotal, 2); ?></h3>

        <button id="yoco-pay-button" type="button">Proceed to Payment</button>

    </div>
    

    <!-- Footer -->
    <footer>
        <class="footer-container" id="footer">
        
        <div><u><center><h3>Contact Us</h3></center></u></div><br><br>

            <table class="center" border-spacing="100px">
                <tr>
                    <td>
                        
                            <p><strong>Physical Address:</strong></p>
                            <p>Innovation Worx Unit b15, Cnr 16th Road, Scale End,<br>
                            Halfway House Estate, Johannesburg, 1688</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Open Hours:</strong><br>
                                Mon-Fri: 9am-5pm<br>
                                    Sat: 9am-3pm<br>
                                    Sun: 9am-1pm</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Contact Information:</strong></p>
                            <p>Phone: 064 944 4905</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Quick Links:</strong></p>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="index.php#products">Shop Now</a></li>
                                <li><a href="https://wa.me/27649444905">Help</a></li>
                                <li><a href="cartpage.php">Cart</a></li>
                                <li><a href="profile.php">Profile</a></li>
                            </ul>
                        
                    </td>
                </tr>
            </table>
        <div class="social-icons">
            <a href="https://www.instagram.com/mpsm_water?igsh=MXcwcGliNXhtNG5uMA==" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://wa.me/27649444905"><i class="fa-brands fa-whatsapp" target="_blank"></i></a>
            <a href=https://www.facebook.com/profile.php?id=100075529239031&mibextid=LQQJ4d target="_blank"><i class="fa-brands fa-facebook"></i></a>
        </div>
        <p>&copy; 2024 MPSM Beverages. All Rights Reserved.</p>
    </footer>

    <script>
        // Toggle between delivery and collection fields
        document.querySelectorAll('input[name="delivery-option"]').forEach((input) => {
            input.addEventListener('change', function() {
                if (this.value === 'address') {
                    document.querySelector('.delivery-fields').style.display = 'block';
                    document.querySelector('.collection-fields').style.display = 'none';
                } else if (this.value === 'pickup') {
                    document.querySelector('.delivery-fields').style.display = 'none';
                    document.querySelector('.collection-fields').style.display = 'block';
                }
            });
        });


        ///////////////////////////////Fetching Address///////////////////////////////////////////

function useSavedAddress() {
    fetch('fetchAddress.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('phone').value = data.phone;
                document.getElementById('street_address').value = data.street_address;
                document.getElementById('suburb_address').value = data.suburb;
                document.getElementById('city').value = data.city;
                document.getElementById('province').value = data.province;
                document.getElementById('postal_code').value = data.postal_code;
                document.getElementById('notes').value = data.notes;
            } else {
                alert('Failed to fetch address');
            }
        })
        .catch(error => console.error('Error:', error));
}

    </script>

   <script>
        const baseSubtotal = <?php echo $subtotal; ?>;
        let deliveryCharge = 120; // Define delivery charge

        function updateTotal() {
            const deliveryOption = document.querySelector('input[name="delivery-option"]:checked').value;
            let totalAmount = (deliveryOption === "address") ? baseSubtotal + deliveryCharge : baseSubtotal;
            document.getElementById("totalDisplay").innerText = `Total: R${totalAmount.toFixed(2)}`;
        }

        // Initialize Yoco
        const yoco = new YocoSDK({
            publicKey: 'pk_live_15070d8bBOJgVWo007d4'
        });

        document.getElementById('yoco-pay-button').addEventListener('click', function() {
            const deliveryOption = document.querySelector('input[name="delivery-option"]:checked').value;
            let finalAmountInCents = (deliveryOption === 'address') ? (baseSubtotal + deliveryCharge) * 100 : baseSubtotal * 100;

            yoco.showPopup({
                amountInCents: finalAmountInCents,
                currency: 'ZAR',
                name: 'MPSM Beverages',
                description: 'Order Payment',
                callback: function(result) {
                    if (result.error) {
                        alert("Payment failed: " + result.error.message);
                    } else {
                        processOrder(result.id, finalAmountInCents);
                    }
                }
            });
        });

        function processOrder(token, amount) {
            const deliveryOption = document.querySelector('input[name="delivery-option"]:checked').value;
            const orderDetails = {
                token: token,
                deliveryOption: deliveryOption,
                totalAmount: amount / 100, // Convert to Rands
            };

            fetch('process_order.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderDetails)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("Payment successful!");
                    window.location.href = 'orders.php';
                } else {
                    alert("Payment processing failed: " + data.message);
                }
            })
            .catch(error => console.error('Error:', error));
        }
    </script>

</body>
</html>