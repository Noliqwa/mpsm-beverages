<?php
session_start(); // Start the session

// Include the database configuration file
include 'config.php';

$alertMessage = ''; // Initialize an empty alert message

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 0) {
        // Email not found
        $alertMessage = "Swal.fire({ icon: 'error', title: 'Email Not Found', text: 'Please check your email or register for a new account.' })";
    } else {
        // Email found, fetch user details
        $user = mysqli_fetch_assoc($result);

        if ($user['is_verified'] == 0) {
            // User is registered but not verified
            $alertMessage = "Swal.fire({ icon: 'error', title: 'User Not Verified', text: 'Please check your emails and verify your account before logging in.' })";
        } elseif (!password_verify($password, $user['password'])) {
            // User is verified, but password is incorrect
            $alertMessage = "Swal.fire({ icon: 'error', title: 'Incorrect Password', text: 'Please try again.' })";
        } else {
            // Successful login: set session variables and update the `is_active` field to 1
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['last_name'] = $user['last_name'];
            $_SESSION['role'] = $user['role'];

            // Update the `is_active` field to 1 for this user
            $updateSql = "UPDATE users SET is_active = 1 WHERE id = " . $user['id'];
            mysqli_query($conn, $updateSql);

            // Redirect based on user role
            header("Location: " . ($user['role'] == 'admin' ? 'dashboard.php' : 'index.php'));
            exit();
        }
    }
}
?>



<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - MPSM Beverages</title>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            justify-content: space-between;
            background-color: #f4f4f4;
        }

        /*----------------- Header styling ---------------*/
header {
    position: sticky;
    top: 0;
    background-color: #fff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

/* Logo styling */
header .logo img {
    width: 200px;
    height: auto; /* Maintain aspect ratio */
}

/* Navigation styling for larger screens */
header nav.nav-menu {
    flex-grow: 1;
    display: flex;
    justify-content: center; /* Center navigation */
}

header nav.nav-menu ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
    padding: 0;

}

header nav.nav-menu ul li a {
    text-decoration: none; /* Remove underline for nav links */
    color: #333;
    font-size: 20px;
    padding: 8px 12px;
    transition: color 0.3s ease;
    
}

header nav.nav-menu ul li a:hover {
    color: #fbb01b; /* Change link color on hover */
}

/* Icons container */
header .icons {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #333b;
    margin-right: 20px;
}

header .icons i {
    font-size: 24px;
    cursor: pointer;
    transition: color 0.3s ease;
    color: black;
    
}

header .icons i:hover {
    color: orange; /* Change icon color on hover */
}

/*---------Hover effect for the navigation----------------------------*/
.hover-effect {
    transition: transform 0.3s ease, opacity 0.3s ease; /* Smooth transition */
}

.hover-effect:hover {
    transform: scale(1.1); /* Scale the image slightly */
    opacity: 0.9; /* Slightly reduce opacity on hover */
}

/* Auth links */
.auth-links {
    display: flex;
    gap: 15px;
    align-items: center;
    margin-right: 15px; /* Adjusted margin */
    justify-content: center;
}

.auth-links ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;
}

.auth-links a {
    text-decoration: none; 
    color: inherit;
    padding: 5px 10px;
    font-size: 16px;
    transition: color 0.3s ease;
}

.auth-links a:hover {
    color: #fbb01b; 
    text-decoration: underline;
}

/* Search bar styling */
.search-container {
    display: flex;
    align-items: center;
    gap: 5px;
    flex-grow: 1; /* Allow search to take up space */
    margin-right: 10px; /* Reduced spacing */
}

#search-input {
    padding: 5px;
    width: 180px;
}

#search-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
}

#search-btn i {
    font-size: 18px;
}

        .login-section {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-box {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }

        .login-box h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        .input-box {
            margin-bottom: 15px;
            text-align: left;
        }

        .input-box label {
            display: block;
            margin-bottom: 5px;
        }

        .input-box input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            padding: 10px 20px;
            background-color: orange;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
           background-color: #ecb74d;
        }

        div.popup-container div.forgot-button.reset-btn{
            font-weight: 550;
            font-style: 15px;
            color: white;
            background-color: #30475e;
            padding: 4px 10px;
            border: none;
            outline: none;
            margin-top: 5px;
        } 

        div.popup-container div.popup div.forgot-btn{
            text-align: right;
        }
        div.popup-container div.forgot-btn button {
            border: none;
            background-color: transparent;
            outline: none;
            font-weight: 450;
            cursor: pointer;

        }
       
        footer {
            background-color: #fff;
            padding: 20px;
            text-align: center;
            border-top: 1px solid #ddd;
            margin-top: 20px;
        }

        footer .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }

        footer .footer-container div {
            width: 30%;
        }

        footer .footer-container .quick-links ul {
            list-style: none;
            padding: 0;
        }

        footer .footer-container .quick-links ul li {
            margin: 5px 0;
        }

        footer .footer-container .quick-links ul li a {
            text-decoration: none;
            color: #333;
        }

        footer .social-icons {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        footer .social-icons img {
            width: 40px;
            height: 40px;
        }

        table {
            border-collapse: separate;
            border-spacing: 50px; /* Space between images */
        }

        td {
            padding: 10px; /* Padding inside each cell */
        }

        .center{
            margin-left: auto;
            margin-right: auto;
        }

        
    </style>
</head>
<body>

    <!-- Header section -->
   <header>
        <div class="logo"><img src="logo.jpg" alt="MPSM Beverages"></div>
        <nav class="nav-menu" aria-label="Main Navigation" >
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php#products">Shop Now</a></li>
                <li><a href="#footer">Contact Us</a></li>
            </ul>
        </nav>
        <div class="icons">
            <div class="search-icon"><a href="search.php"><i class="fa-solid fa-magnifying-glass"></i></a></div>
        </div>
    </header>

    <!-- Login section -->
    <section class="login-section">
        <div class="login-box">
            <h2>Login</h2>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

                <div class="input-box">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="input-box">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit">LOGIN</button>
            </form>
            <br>
            <p>Don’t have an account? <a href="registrationpage.php">Register Here</a></p>
            <br><a href="forgot_password.php">Forgot Password?</a>
        </div>
        
    </section>

   
    <!-- Footer -->
      <footer>
        <class="footer-container" id="footer">
        
        <div><u><center><h3>Contact Us</h3></center></u></div><br><br>

            <table class="center" border-spacing="100px">
                <tr>
                    <td>
                        
                            <p><strong>Physical Address:</strong></p>
                            <p>Innovation Worx Unit b15, Cnr 16th Road, Scale End,<br>
                            Halfway House Estate, Johannesburg, 1688</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Open Hours:</strong><br>
                                Mon-Fri: 9am-5pm<br>
                                    Sat: 9am-3pm<br>
                                    Sun: 9am-1pm</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Contact Information:</strong></p>
                            <p>Phone: 064 944 4905</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Quick Links:</strong></p>
                            <ul>
                                <li><a href="homepage.php">Home</a></li>
                                <li><a href="homepage.php#products">Shop Now</a></li>
                                <li><a href="">Help</a></li>
                                <li><a href="cartpage.php">Cart</a></li>
                                <li><a href="profile.php">Profile</a></li>
                            </ul>
                        
                    </td>
                </tr>
            </table>
        <div class="social-icons">
            <a href="https://www.instagram.com/mpsm_water?igsh=MXcwcGliNXhtNG5uMA==" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://wa.me/27649444905"><i class="fa-brands fa-whatsapp" target="_blank"></i></a>
            <a href=https://www.facebook.com/profile.php?id=100075529239031&mibextid=LQQJ4d target="_blank"><i class="fa-brands fa-facebook"></i></a>
        </div>
        <p>&copy; 2024 MPSM Beverages. All Rights Reserved.</p>
    </footer>
    <!-- SweetAlert Message Script -->
    <script>
        <?php if (!empty($alertMessage)) : ?>
            <?php echo $alertMessage; ?>.then(function() {
                window.location.href = 'loginpage.php'; // Redirect to login page after alert
            });
        <?php endif; ?>
        function popup(popup_name)
        {
            get_popup=document.getElementById(popup_name);
            if(get_popup.style.display=="flex")
        {
            get_popup.style.display="none";
        }
        else
        {
            get_popup.style.display="flex";
        }
        }

        function forgotPopup(){
            document.getElementById('forgot-popup').style.display="flex";
        }
    </script>

</body>
</html>