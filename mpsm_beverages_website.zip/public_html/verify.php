<?php
require('config.php');

// Start session and check if email and v_code parameters are set in the URL
if (isset($_GET['email']) && isset($_GET['v_code'])) {
    $email = $conn->real_escape_string($_GET['email']);
    $v_code = $conn->real_escape_string($_GET['v_code']);

    // Fetch user based on email and verification code
    $sql = "SELECT * FROM users WHERE email='$email' AND verification_code='$v_code' AND is_verified = 0";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User found, update the verification status
        $update_sql = "UPDATE users SET is_verified = 1, verification_code = NULL WHERE email='$email'";
        
        if ($conn->query($update_sql) === TRUE) {
            // Verification successful
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
            echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Email Verified!',
                        text: 'Your email has been successfully verified. You can now log in.',
                        confirmButtonText: 'Go to Login'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'loginpage.php';
                        }
                    });
                  </script>";
        } else {
            // Verification update failed
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
            echo "<script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Verification Failed',
                        text: 'An error occurred while updating your verification status.',
                    });
                  </script>";
        }
    } else {
        // Invalid or already verified link
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
        echo "<script>
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Verification Link',
                    text: 'The link is either invalid or your email is already verified.',
                });
              </script>";
    }
} else {
    // Missing parameters
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
    echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Invalid Access',
                text: 'No verification information provided.',
            });
          </script>";
}

// Close the database connection
$conn->close();
?>
