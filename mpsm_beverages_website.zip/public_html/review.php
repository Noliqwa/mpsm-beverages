<?php
// Start the session to ensure user ID is available
session_start();
include('config.php');

// Sanitize incoming ItemID (product ID) to avoid security risks
$ItemID = isset($_GET['products_ItemID']) ? intval($_GET['products_ItemID']) : 0;

// Fetch product details (name and image) from the database
$stmt = $conn->prepare("SELECT productName, imageURL FROM products WHERE ItemID = ?");
$stmt->bind_param("i", $ItemID);
$stmt->execute();
$productResult = $stmt->get_result();
$product = $productResult->fetch_assoc();
$stmt->close();

$userReviews = []; // Array to store user's previous reviews
if (isset($_SESSION['user_id'])) {
    $userID = $_SESSION['user_id'];

    // Fetch all reviews for this product by the logged-in user
    $stmt = $conn->prepare("SELECT reviewID, rating, reviewText, created_at FROM reviews WHERE ItemID = ? AND user_id = ?");
    $stmt->bind_param("ii", $ItemID, $userID);
    $stmt->execute();
    $userReviewResult = $stmt->get_result();
    while ($row = $userReviewResult->fetch_assoc()) {
        $userReviews[] = $row;
    }
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MPSM Beverages</title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        /* General styling */
        body { 
        background-color: #f9f9f9; 
        font-family: Arial, sans-serif; 
        }
   /*----------------- Header styling ---------------*/
header {
    position: sticky;
    top: 0;
    background-color: #fff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

/* Logo styling */
header .logo img {
    width: 200px;
    height: auto; /* Maintain aspect ratio */
}

/* Navigation styling for larger screens */
header nav.nav-menu {
    flex-grow: 1;
    display: flex;
    justify-content: center; /* Center navigation */
}

header nav.nav-menu ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
    padding: 0;

}

header nav.nav-menu ul li a {
    text-decoration: none; /* Remove underline for nav links */
    color: #333;
    font-size: 20px;
    padding: 8px 12px;
    transition: color 0.3s ease;
    
}

header nav.nav-menu ul li a:hover {
    color: #fbb01b; /* Change link color on hover */
}

/* Icons container */
header .icons {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #333b;
    margin-right: 20px;
}

header .icons i {
    font-size: 24px;
    cursor: pointer;
    transition: color 0.3s ease;
    color: black;
    
}

header .icons i:hover {
    color: orange; /* Change icon color on hover */
}

/*---------Hover effect for the navigation----------------------------*/
.hover-effect {
    transition: transform 0.3s ease, opacity 0.3s ease; /* Smooth transition */
}

.hover-effect:hover {
    transform: scale(1.1); /* Scale the image slightly */
    opacity: 0.9; /* Slightly reduce opacity on hover */
}

/* Auth links */
.auth-links {
    display: flex;
    gap: 15px;
    align-items: center;
    margin-right: 15px; /* Adjusted margin */
    justify-content: center;
}

.auth-links ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;
}

.auth-links a {
    text-decoration: none; /* Ensure no underline */
    color: inherit;
    padding: 5px 10px;
    font-size: 16px;
    transition: color 0.3s ease;
}

.auth-links a:hover {
    color: #fbb01b; /* Change color on hover */
    text-decoration: underline;
}

/* Search bar styling */
.search-container {
    display: flex;
    align-items: center;
    gap: 5px;
    flex-grow: 1; /* Allow search to take up space */
    margin-right: 10px; /* Reduced spacing */
}

#search-input {
    padding: 5px;
    width: 180px;
}

#search-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
}

#search-btn i {
    font-size: 18px;
}

        .table { 
        width: 80%; m
        argin: 20px auto; 
        border-collapse: collapse; 
        }
        .table, .table th, .table td {
         border: 1px solid #ddd; 
         padding: 10px; 
         }
        button { 
        padding: 10px 20px; 
        background-color: orange; 
        color: #fff; 
        border: none; 
        cursor: pointer; 
        }
        button:hover {
         background-color: green; 
         }
        .modal { 
        display: none; 
        position: fixed;
         top: 0; left: 0; 
         width: 100%; 
         height: 100%; 
         background: rgba(0,0,0,0.5);
          }
        .modal-content {
         background: #fff; 
         margin: 15% auto; 
         padding: 20px; 
         width: 50%; 
         }
        .stars {
         display: 
         flex; gap: 5px; 
         }
        .star { 
        font-size: 30px; 
        cursor: pointer; 
        color: gray; 
        }
        .star.selected { 
        color: gold; 
        }
        footer {
            background-color: #fff;
            padding: 20px;
            text-align: center;
            border-top: 1px solid #ddd;
            margin-top: 20px;
        }
        footer .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }
        footer .footer-container div {
            width: 30%;
        }
        footer .footer-container .quick-links ul {
            list-style: none;
            padding: 0;
        }
        footer .footer-container .quick-links ul li {
            margin: 5px 0;
        }
        footer .footer-container .quick-links ul li a {
            text-decoration: none;
            color: #333;
        }
        footer .social-icons {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        footer .social-icons img {
            width: 40px;
            height: 40px;
        }

        table {
            border-collapse: separate;
            border-spacing: 20px; /* Space between images */
        }
        td {
            padding: 10px; /* Padding inside each cell */
        }
        table img {
            width: 150px; /* Adjust the size of the image */
            height: auto;
            border-radius: 50%;
        }
        .center{
            margin-left: auto;
            margin-right: auto;
        } 
    </style>
</head>
<body>

<header>
        <div class="logo"><img src="logo.jpg" alt="MPSM Beverages"></div>
        <nav class="nav-menu" aria-label="Main Navigation" >
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php#products">Shop Now</a></li>
                <li><a href="orders.php">Orders</a></li>
                <li><a href="#footer">Contact Us</a></li>
            </ul>
        </nav>
        <div class="icons">
            <div class="search-icon"><a href="search.php"><i class="fa-solid fa-magnifying-glass"></i></a></div>
            <div class="cart-icon"><a href="cartpage.php"><i class="fa-solid fa-cart-shopping"></i></a></div>
            <div class="profile-icon"><a href="profile.php"><i class="fa-solid fa-user"></i></a></div>
        </div>
    </header>

<main>
    <section ><center>
        <h1><?= htmlspecialchars($product['productName'] ?? 'Product') ?></h1>
        <img src="<?= htmlspecialchars($product['imageURL'] ?? 'default.jpg') ?>" alt="<?= htmlspecialchars($product['productName'] ?? 'Product') ?>" style="width: 300px; height: auto;">
    </center></section>

    <h2>Product Reviews</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Rating</th>
                <th>Reviewer</th>
                <th>Review</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $stmt = $conn->prepare("SELECT reviews.rating, reviews.reviewText, reviews.reviewerName, reviews.created_at FROM reviews WHERE reviews.ItemID = ?");
            $stmt->bind_param("i", $ItemID);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $ratingStars = str_repeat('★', $row['rating']) . str_repeat('☆', 5 - $row['rating']);
                    echo "<tr>
                            <td>$ratingStars</td>
                            <td>" . htmlspecialchars($row['reviewerName'] ?: 'Anonymous') . "</td>
                            <td>" . htmlspecialchars($row['reviewText']) . "</td>
                            <td>" . htmlspecialchars($row['created_at']) . "</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No reviews yet. Be the first to review!</td></tr>";
            }
            $stmt->close();
            ?>
        </tbody>
    </table>
    <br><br>
    <div><center>
        <?php if (isset($_SESSION['user_id'])): ?>
            <button onclick="document.getElementById('reviewModal').style.display='block'">Leave a Review</button>
        <?php else: ?>
            <p>Please <a href="registrationpage.php">register</a> / <a href="loginpage.php">login</a> first in order to leave a review.</p>
        <?php endif; ?>
    </center></div>
    <br>   
</main>

<footer>
        <class="footer-container" id="footer">
        
        <div><u><center><h3>Contact Us</h3></center></u></div><br><br>

            <table class="center" border-spacing="100px">
                <tr>
                    <td>
                        
                            <p><strong>Physical Address:</strong></p>
                            <p>Innovation Worx Unit b15, Cnr 16th Road, Scale End,<br>
                            Halfway House Estate, Johannesburg, 1688</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Open Hours:</strong><br>
                                Mon-Fri: 9am-5pm<br>
                                    Sat: 9am-3pm<br>
                                    Sun: 9am-1pm</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Contact Information:</strong></p>
                            <p>Phone: 064 944 4905</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Quick Links:</strong></p>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="index.php#products">Shop Now</a></li>
                                <li><a href="">Help</a></li>
                                <li><a href="cartpage.php">Cart</a></li>
                                <li><a href="profile.php">Profile</a></li>
                            </ul>
                        
                    </td>
                </tr>
            </table>
        <div class="social-icons">
            <a href="https://www.instagram.com/mpsm_water?igsh=MXcwcGliNXhtNG5uMA==" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://wa.me/27649444905"><i class="fa-brands fa-whatsapp" target="_blank"></i></a>
            <a href=https://www.facebook.com/profile.php?id=100075529239031&mibextid=LQQJ4d target="_blank"><i class="fa-brands fa-facebook"></i></a>
        </div>
        <p>&copy; 2024 MPSM Beverages. All Rights Reserved.</p>
    </footer>

<!-- Review Modal -->
<div id="reviewModal" class="modal">
    <div class="modal-content">
        <span onclick="document.getElementById('reviewModal').style.display='none'" style="float:right;cursor:pointer">&times;</span>
        
        <h3>Your Previous Reviews</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Rating</th>
                        <th>Review</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($userReviews)): ?>
                        <?php foreach ($userReviews as $review): ?>
                            <tr>
                                <td><?= str_repeat('★', $review['rating']) . str_repeat('☆', 5 - $review['rating']); ?></td>
                                <td><?= htmlspecialchars($review['reviewText']); ?></td>
                                <td><?= htmlspecialchars($review['created_at']); ?></td>
                                <td>
                                    <button onclick="editReview(<?= $review['reviewID']; ?>)">Edit</button>
                                    <button onclick="deleteReview(<?= $review['reviewID']; ?>)">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4">No reviews submitted yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        
        <h3>Leave a Review</h3>
        <form action="submit_review.php" method="POST">
            <input type="hidden" name="ItemID" value="<?= htmlspecialchars($ItemID); ?>">
            <label for="rating">Rating (1-5):</label><br>
            <div class="stars">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                    <span class="star" onclick="selectStarRating(<?= $i ?>)">★</span>
                <?php endfor; ?>
            </div>
            <input type="hidden" name="rating" id="rating" value="5"><br><br>
            <label for="reviewText">Your Review:</label><br>
            <textarea name="reviewText" id="reviewText" rows="4" required></textarea><br><br>
            <label for="reviewerName">Your Name (Optional):</label><br>
            <input type="text" name="reviewerName" id="reviewerName"><br><br>
            <button type="submit">Submit Review</button>
        </form>
    </div>
</div>

<script>
    function selectStarRating(rating) {
        document.getElementById('rating').value = rating;
        const stars = document.querySelectorAll('.star');
        stars.forEach((star, index) => star.classList.toggle('selected', index < rating));
    }
    // Function to parse query parameters
    function getQueryParameter(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    function editReview(reviewID) {
        // Redirect to edit review page or open an edit form
        window.location.href = `edit_review.php?reviewID=${reviewID}`;
    }

    function deleteReview(reviewID) {
        // Use SweetAlert for confirmation before deletion
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Perform the delete action with fetch
                fetch(`delete_review.php?reviewID=${reviewID}`, { method: 'GET' })
                    .then(response => response.text())
                    .then(data => {
                        console.log("Response from server:", data); // Log the response for debugging
                        if (data.trim() === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: 'Review deleted successfully.',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: 'Failed to delete review. Please try again.',
                                confirmButtonText: 'OK'
                            });
                            console.error("Error deleting review:", data); // Log any errors
                        }
                    })
                    .catch(error => {
                        console.error("Error:", error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'An error occurred while deleting the review. Please check your network or contact support.',
                            confirmButtonText: 'OK'
                        });
                    });
            }
        });
    }

 

    // Show SweetAlert based on success or error parameters
    document.addEventListener('DOMContentLoaded', function () {
        const success = getQueryParameter('success');
        const error = getQueryParameter('error');

        if (success) {
            Swal.fire({
                icon: 'success',
                title: 'Review Submitted!',
                text: 'Your review has been successfully submitted.',
                confirmButtonText: 'Okay'
            });
        } else if (error) {
            let errorMessage;
            switch(error) {
                case 'invalid_rating':
                    errorMessage = 'Invalid rating. Please provide a rating between 1 and 5.';
                    break;
                case 'product_not_found':
                    errorMessage = 'Error: The specified product does not exist.';
                    break;
                case 'execution_failed':
                    errorMessage = 'Error saving review. Please try again.';
                    break;
                case 'prepare_failed':
                    errorMessage = 'Error preparing the submission. Please contact support.';
                    break;
                default:
                    errorMessage = 'An unknown error occurred.';
            }

            Swal.fire({
                icon: 'error',
                title: 'Submission Failed',
                text: errorMessage,
                confirmButtonText: 'Okay'
            });
        }
    });

</script>


</body>
</html>
