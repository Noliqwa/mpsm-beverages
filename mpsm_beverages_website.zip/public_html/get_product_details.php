<?php
include 'config.php';  // Include the config.php file

// Log the database connection success/failure
if ($conn) {
    log_debug("Database connected successfully");
} else {
    log_debug("Database connection failed");
}

$debug_log = 'debug_log.txt';

ini_set('display_errors', 0);  // Disable displaying errors to users
ini_set('log_errors', 1);      // Enable logging errors to debug_log.txt
error_reporting(E_ALL);

function handleError($errno, $errstr, $errfile, $errline) {
    global $debug_log;
    error_log("Error [$errno] in $errfile at line $errline: $errstr", 3, $debug_log);
    // Make sure we don't output anything before the header
    http_response_code(500);  // Internal server error status code
    echo json_encode(['error' => "An error occurred. Please check the logs."]);
    exit();  // Ensure the script stops here
}
set_error_handler("handleError");

function log_debug($message) {
    global $debug_log;
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($debug_log, "[$timestamp] $message" . PHP_EOL, FILE_APPEND);
}

header('Content-Type: application/json');  // Make sure it's set before any output

// Ensure that item_id is provided in the request
if (isset($_GET['item_id'])) {
    $itemId = intval($_GET['item_id']);
    log_debug("Received request to fetch product details for ItemID: $itemId");

    // Check the database connection
    if ($conn->connect_error) {
        log_debug("Database connection error: " . $conn->connect_error);
        http_response_code(500);
        echo json_encode(['error' => 'Database connection failed']);
        exit();
    }

    // Prepare the query to fetch the product details
    $query = $conn->prepare("SELECT * FROM products WHERE ItemID = ?");
    if ($query === false) {
        log_debug("SQL error (prepare): " . $conn->error);
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
        exit();
    }

    // Bind the parameter and execute the query
    $query->bind_param('i', $itemId);
    if (!$query->execute()) {
        log_debug("SQL error (execute): " . $query->error);
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
        exit();
    }

    // Get the result and return the product details
    $result = $query->get_result();
    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
        log_debug("Product details retrieved successfully for ItemID: $itemId");
        echo json_encode($product);  // Return the product details in JSON format
    } else {
        log_debug("No product found with ItemID: $itemId");
        http_response_code(404);  // Return 404 if product is not found
        echo json_encode(['error' => 'Product not found']);
    }

    // Close the query and connection
    $query->close();
    $conn->close();
} else {
    log_debug("No item_id parameter provided in the request");
    http_response_code(400);  // Bad Request if item_id is missing
    echo json_encode(['error' => 'Invalid request']);
}
?>
