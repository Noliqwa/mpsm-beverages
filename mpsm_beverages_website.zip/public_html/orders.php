<?php
// Database connection details
$host = "localhost";  // database host
$db_user = "bofsfkhe_mpsmecommerce";     // database username
$db_password = "PHPNRgUgRvuhJVuBR2De";     // database password
$db_name = "bofsfkhe_mpsmecommerce"; // database name
$charset = 'utf8mb4';


// Create connection
$conn = new mysqli($host, $db_user, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    $token = $input['token'];
    $orderDetails = $input['orderDetails'];

    // Call Yoco API to charge the token
    $ch = curl_init('https://online.yoco.com/v1/charges/');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'X-Auth-Secret-Key: sk_live_c09ee7e4mpNYz8nac134355a0dbe',
        'Content-Type: application/json'
    ));
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'token' => $token,
        'amountInCents' => 5000, // This should match the amount specified in the front-end
        'currency' => 'ZAR'
    ]));

    $response = curl_exec($ch);
    $response_data = json_decode($response, true);
    curl_close($ch);

    if (isset($response_data['status']) && $response_data['status'] === 'successful') {
        // Save the order and payment details in your database here

        echo json_encode(['success' => true, 'message' => 'Payment successful']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Payment failed']);
    }
}

// Fetch current orders (only those where payment is completed)
$currentOrdersSql = "SELECT o.order_number, i.product_name, o.created_at AS order_date, 
                     o.shipment_date, i.price, o.status
                     FROM orders o 
                     JOIN order_items i ON o.id = i.order_id
                     WHERE o.status IN ('Confirmed', 'Processing', 'Out for delivery', 'Shipped', 'Ready for collection')";
$currentOrdersResult = $conn->query($currentOrdersSql);

// Fetch order history (for completed orders)
$orderHistorySql = "SELECT o.order_number, i.product_name, o.created_at AS order_date, 
                    o.shipment_date, i.price, o.status
                    FROM orders o 
                    JOIN order_items i ON o.id = i.order_id
                    WHERE o.status IN ('Delivered', 'Collected')";
$orderHistoryResult = $conn->query($orderHistorySql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MPSM Beverages</title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Arial, sans-serif;
    }
    body {
        background-color: #f9f9f9;
    }
   /*----------------- Header styling ---------------*/
header {
    position: sticky;
    top: 0;
    background-color: #fff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

/* Logo styling */
header .logo img {
    width: 200px;
    height: auto; /* Maintain aspect ratio */
}

/* Navigation styling for larger screens */
header nav.nav-menu {
    flex-grow: 1;
    display: flex;
    justify-content: center; /* Center navigation */
}

header nav.nav-menu ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
    padding: 0;

}

header nav.nav-menu ul li a {
    text-decoration: none; /* Remove underline for nav links */
    color: #333;
    font-size: 20px;
    padding: 8px 12px;
    transition: color 0.3s ease;
    
}

header nav.nav-menu ul li a:hover {
    color: #fbb01b; /* Change link color on hover */
}

/* Icons container */
header .icons {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #333b;
    margin-right: 20px;
}

header .icons i {
    font-size: 24px;
    cursor: pointer;
    transition: color 0.3s ease;
    color: black;
    
}

header .icons i:hover {
    color: orange; /* Change icon color on hover */
}

/*---------Hover effect for the navigation----------------------------*/
.hover-effect {
    transition: transform 0.3s ease, opacity 0.3s ease; /* Smooth transition */
}

.hover-effect:hover {
    transform: scale(1.1); /* Scale the image slightly */
    opacity: 0.9; /* Slightly reduce opacity on hover */
}

/* Auth links */
.auth-links {
    display: flex;
    gap: 15px;
    align-items: center;
    margin-right: 15px; /* Adjusted margin */
    justify-content: center;
}

.auth-links ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;
}

.auth-links a {
    text-decoration: none; /* Ensure no underline */
    color: inherit;
    padding: 5px 10px;
    font-size: 16px;
    transition: color 0.3s ease;
}

.auth-links a:hover {
    color: #fbb01b; /* Change color on hover */
    text-decoration: underline;
}

/* Search bar styling */
.search-container {
    display: flex;
    align-items: center;
    gap: 5px;
    flex-grow: 1; /* Allow search to take up space */
    margin-right: 10px; /* Reduced spacing */
}

#search-input {
    padding: 5px;
    width: 180px;
}

#search-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
}

#search-btn i {
    font-size: 18px;
}

    .order-section {
    width: 80%;
    margin: auto;
    padding: 20px;
}

.order-section table {
    width: 100%;
    border-collapse: collapse;
}

.order-section table, th, td {
    border: 1px solid #ddd;
}

.order-section th, td {
    padding: 10px;
    text-align: center;
}

.order-note {
    margin-top: 20px;
    color: red;
}
 footer {
            background-color: #ff790e;
            padding: 20px;
            text-align: center;
            border-top: 1px solid #ddd;
            margin-top: 20px;
        }
        footer .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }
        footer .footer-container div {
            width: 50%;
        }
        footer .footer-container .quick-links ul {
            list-style: none;
            padding: 0;
        }
        footer .footer-container .quick-links ul li {
            margin: 5px 0;
        }
        footer .footer-container .quick-links ul li a {
            text-decoration: none;
            color: #333;
        }
        footer .social-icons {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        footer .social-icons i{
            font-size: 40px; /* Adjust icon size */
        color: #333; /* Adjust icon color as needed */
        }
        table {
            border-collapse: separate;
            border-spacing: 20px; /* Space between images */
        }
        td {
            padding: 10px; /* Padding inside each cell */
        }
        table img {
            width: 150px; /* Adjust the size of the image */
            height: auto;
            border-radius: 50%;
        }
        .center{
            margin-left: auto;
            margin-right: auto;
        }
        footer table {
    border: none;
}

footer table td {
    border: none;
}


</style>
</head>
<body>

    <header>
        <div class="logo"><img src="logo.jpg" alt="MPSM Beverages"></div>
        <nav class="nav-menu" aria-label="Main Navigation" >
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php#products">Shop Now</a></li>
                <li><a href="#footer">Contact Us</a></li>
            </ul>
        </nav>
        <div class="icons">
            <div class="search-icon"><a href="search.php"><i class="fa-solid fa-magnifying-glass"></i></a></div>
            <div class="cart-icon"><a href="cartpage.php"><i class="fa-solid fa-cart-shopping"></i></a></div>
            <div class="profile-icon"><a href="profile.php"><i class="fa-solid fa-user"></i></a></div>
        </div>
    </header>


   <div class="order-section">
        <h2>Current Orders</h2>
        <table>
            <tr>
                <th>Order #</th>
                <th>Product</th>
                <th>Order Date</th>
                <th>Delivery/Collection Date</th>
                <th>Price</th>
                <th>Status</th>
            </tr>
            <?php while ($row = $currentOrdersResult->fetch_assoc()) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['order_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['order_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['shipment_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['price']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
            <?php endwhile; ?>
        </table>

        <h2>Order History</h2>
        <table>
            <tr>
                <th>Order #</th>
                <th>Product</th>
                <th>Order Date</th>
                <th>Date Delivered/Collected</th>
                <th>Price</th>
                <th>Status</th>
            </tr>
            <?php while ($row = $orderHistoryResult->fetch_assoc()) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['order_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['order_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['shipment_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['price']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
            <?php endwhile; ?>
        </table>

        <p class="order-note">* Please note that orders take up to 3-5 working days to be processed and delivered.</p>
    </div>

    <!-- Footer -->
    <footer>
        <class="footer-container" id="footer">
        
        <div><u><center><h3>Contact Us</h3></center></u></div><br><br>

            <table class="center" cell-padding="100px">
                <tr>
                    <td>
                        
                            <p><strong>Physical Address:</strong></p>
                            <p>Innovation Worx Unit b15, Cnr 16th Road, Scale End,<br>
                            Halfway House Estate, Johannesburg, 1688</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Open Hours:</strong><br>
                                Mon-Fri: 9am-5pm<br>
                                    Sat: 9am-3pm<br>
                                    Sun: 9am-1pm</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Contact Information:</strong></p>
                            <p>Phone: 064 944 4905</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Quick Links:</strong></p>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="index.php#products">Shop Now</a></li>
                                <li><a href="https://wa.me/27649444905">Help</a></li>
                                <li><a href="cartpage.php">Cart</a></li>
                                <li><a href="profile.php">Profile</a></li>
                            </ul>
                        
                    </td>
                </tr>
            </table>
        <div class="social-icons">
            <a href="https://www.instagram.com/mpsm_water?igsh=MXcwcGliNXhtNG5uMA==" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://wa.me/27649444905"target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
            <a href=https://www.facebook.com/profile.php?id=100075529239031&mibextid=LQQJ4d target="_blank"><i class="fa-brands fa-facebook"></i></a>
        </div><br><br>
        <p>&copy; 2024 MPSM Beverages. All Rights Reserved.</p>
    </footer>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>