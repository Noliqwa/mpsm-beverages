<?php
session_start();
require 'config.php';  // Add your DB connection
echo "connection_successful";

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    die('Your cart is empty.');
}

// Start transaction
$pdo->beginTransaction();

try {
    foreach ($_SESSION['cart'] as $sku => $item) {
        // Update stock level in the database
        $stmt = $pdo->prepare("UPDATE products SET stockLevel = stockLevel - ? WHERE SKU = ?");
        $stmt->execute([$item['quantity'], $sku]);

        // You can also add an order history table if necessary
    }

    // Commit the transaction
    $pdo->commit();

    // Clear the cart
    unset($_SESSION['cart']);

    echo "Checkout successful!";
} catch (Exception $e) {
    $pdo->rollBack();
    echo "Checkout failed: " . $e->getMessage();
}
?>
