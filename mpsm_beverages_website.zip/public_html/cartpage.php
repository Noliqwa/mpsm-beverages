<?php
session_start();
$host = "localhost";
$db_user = "bofsfkhe_mpsmecommerce";
$db_password = "PHPNRgUgRvuhJVuBR2De";
$db_name = "bofsfkhe_mpsmecommerce";
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";
try {
    $pdo = new PDO($dsn, $db_user, $db_password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}
function calculateSubtotal() {
    $cartItems = isset($_SESSION['cartItems']) ? $_SESSION['cartItems'] : [];
    $subtotal = 0;
    foreach ($cartItems as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
    return $subtotal;
}

// Calculate subtotal and store it in session
$subtotal = calculateSubtotal();
$_SESSION['subtotal'] = $subtotal;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background-color: #f9f9f9;
        }
        /*----------------- Header styling ---------------*/
header {
    position: sticky;
    top: 0;
    background-color: #fff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

/* Logo styling */
header .logo img {
    width: 200px;
    height: auto; /* Maintain aspect ratio */
}

/* Navigation styling for larger screens */
header nav.nav-menu {
    flex-grow: 1;
    display: flex;
    justify-content: center; /* Center navigation */
}

header nav.nav-menu ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
    padding: 0;

}

header nav.nav-menu ul li a {
    text-decoration: none; /* Remove underline for nav links */
    color: #333;
    font-size: 20px;
    padding: 8px 12px;
    transition: color 0.3s ease;
    
}

header nav.nav-menu ul li a:hover {
    color: #fbb01b; /* Change link color on hover */
}

/* Icons container */
header .icons {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #333b;
    margin-right: 20px;
}

header .icons i {
    font-size: 24px;
    cursor: pointer;
    transition: color 0.3s ease;
    color: black;
    
}

header .icons i:hover {
    color: orange; /* Change icon color on hover */
}

/*---------Hover effect for the navigation----------------------------*/
.hover-effect {
    transition: transform 0.3s ease, opacity 0.3s ease; /* Smooth transition */
}

.hover-effect:hover {
    transform: scale(1.1); /* Scale the image slightly */
    opacity: 0.9; /* Slightly reduce opacity on hover */
}

/* Auth links */
.auth-links {
    display: flex;
    gap: 15px;
    align-items: center;
    margin-right: 15px; /* Adjusted margin */
    justify-content: center;
}

.auth-links ul {
    list-style: none;
    padding: 0;
    display: flex;
    margin: 0;
}

.auth-links a {
    text-decoration: none; /* Ensure no underline */
    color: inherit;
    padding: 5px 10px;
    font-size: 16px;
    transition: color 0.3s ease;
}

.auth-links a:hover {
    color: #fbb01b; /* Change color on hover */
    text-decoration: underline;
}

/* Search bar styling */
.search-container {
    display: flex;
    align-items: center;
    gap: 5px;
    flex-grow: 1; /* Allow search to take up space */
    margin-right: 10px; /* Reduced spacing */
}

#search-input {
    padding: 5px;
    width: 180px;
}

#search-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
}

#search-btn i {
    font-size: 18px;
}


        .cart-icon {
            font-size: 18px;
            position: relative;
        }

        .cart-page {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .cart-container {
            background-color: #fff;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .cart-container h1 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        .continue-browsing {
            display: inline-block;
            margin-bottom: 20px;
            color: #555;
            text-decoration: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        table th, table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        .subtotal-section {
            font-size: 24px;
            margin-bottom: 20px;
        }
        .subtotal-section h2 {
            font-weight: normal;
        }

        .checkout-section {
            margin-top: 30px;
        }

        .checkout-section button {
             background-color: orange;
            color: #fff;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s;
        }
        .chechout-secrion button:hover {
           background-color: #ecb74d;
        }

        .checkout-section button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }
        a {
        text-decoration: none;
    }

       footer {
            background-color: #ff790e;
            padding: 20px;
            text-align: center;
            border-top: 1px solid #ddd;
            margin-top: 20px;
        }
        footer .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }
        footer .footer-container div {
            width: 50%;
        }
        footer .footer-container .quick-links ul {
            list-style: none;
            padding: 0;
        }
        footer .footer-container .quick-links ul li {
            margin: 5px 0;
        }
        footer .footer-container .quick-links ul li a {
            text-decoration: none;
            color: #333;
        }
        footer .social-icons {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        footer .social-icons i{
            font-size: 40px; /* Adjust icon size */
        color: #333; /* Adjust icon color as needed */
        }
        table {
            border-collapse: separate;
            border-spacing: 20px; /* Space between images */
        }
        td {
            padding: 10px; /* Padding inside each cell */
        }
        table img {
            width: 150px; /* Adjust the size of the image */
            height: auto;
            border-radius: 50%;
        }
        .center{
            margin-left: auto;
            margin-right: auto;
        } 
    </style>
</head>
<body>
    
    <!-- Header -->
    <header>
        <div class="logo"><img src="logo.jpg" alt="MPSM Beverages"></div>
        <nav class="nav-menu" aria-label="Main Navigation" >
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php#products">Shop Now</a></li>
                <li><a href="#footer">Contact Us</a></li>
            </ul>
        </nav>
        <div class="icons">
            <div class="search-icon"><a href="search.php"><i class="fa-solid fa-magnifying-glass"></i></a></div>
            <div class="cart-icon"><a href="cartpage.php"><i class="fa-solid fa-cart-shopping"></i></a></div>
            <div class="profile-icon"><a href="profile.php"><i class="fa-solid fa-user"></i></a></div>
        </div>
    </header>
    
    <div class="cart-page">
        <section class="cart-container">
            <h1>Your Cart</h1>
            <a href="index.php#products" class="continue-browsing">← Continue browsing</a>

            <table id="cart-content">
                <thead>
                    <tr>
                        <th>Product Image</th>
                        <th>Product Name</th>
                        <th>Price (R)</th>
                        <th>Quantity</th>
                        <th>Total (R)</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $userID = $_SESSION['user_id'];
                    $stmt = $pdo->prepare("SELECT * FROM cart WHERE userID = ?");
                    $stmt->execute([$userID]);
                    $cartItems = $stmt->fetchAll();

                    $subtotal = 0;

                    if (!empty($cartItems)) {
                        foreach ($cartItems as $item) {
                            $totalPrice = $item['Price'] * $item['quantity'];
                            $subtotal += $totalPrice;
                            echo "<tr>
                                    <td><img src='{$item['imageURL']}' alt='{$item['productName']}' width='50' height='50'></td>
                                    <td>{$item['productName']}</td>
                                    <td>R" . number_format($item['Price'], 2) . "</td>
                                    <td><input type='number' value='{$item['quantity']}' onchange='updateQuantity({$item['cartID']}, this.value)'></td>
                                    <td>R" . number_format($totalPrice, 2) . "</td>
                                    <td><button onclick='deleteFromCart({$item['cartID']})'>Remove</button></td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>Your cart is empty.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>

            <div class="subtotal-section">
                <h2>Subtotal: R<span id="subtotal"><?php echo number_format($subtotal, 2); ?></span></h2>
                <p>The above total is an estimated amount, calculation before delivery costs.</p>
            </div>

            <div class="checkout-section">
                <input type="checkbox" id="terms">
                <label for="terms">I acknowledge and agree that my order processing will commence upon receipt of my payment and my order will take 3 to 5 days to be ready for cllection or delivery.</label>
                <br>
                <a href="deliverypage.php?subtotal=<?php echo $subtotal; ?>"><button id="checkout-btn" disabled>Checkout</button></a>
            </div>
        </section>
    </div>

   <footer>
        <class="footer-container" id="footer">
        
        <div><u><center><h3>Contact Us</h3></center></u></div><br><br>

            <table class="center" border-spacing="100px">
                <tr>
                    <td>
                        
                            <p><strong>Physical Address:</strong></p>
                            <p>Innovation Worx Unit b15, Cnr 16th Road, Scale End,<br>
                            Halfway House Estate, Johannesburg, 1688</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Open Hours:</strong><br>
                                Mon-Fri: 9am-5pm<br>
                                    Sat: 9am-3pm<br>
                                    Sun: 9am-1pm</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Contact Information:</strong></p>
                            <p>Phone: 064 944 4905</p>
                        
                    </td>
                    <td>
                        
                            <p><strong>Quick Links:</strong></p>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="index.php#products">Shop Now</a></li>
                                <li><a href="https://wa.me/27649444905">Help</a></li>
                                <li><a href="cartpage.php">Cart</a></li>
                                <li><a href="profile.php">Profile</a></li>
                            </ul>
                        
                    </td>
                </tr>
            </table>
        <div class="social-icons">
            <a href="https://www.instagram.com/mpsm_water?igsh=MXcwcGliNXhtNG5uMA==" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://wa.me/27649444905" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
            <a href=https://www.facebook.com/profile.php?id=100075529239031&mibextid=LQQJ4d target="_blank"><i class="fa-brands fa-facebook"></i></a>
        </div><br><br>
        <p>&copy; 2024 MPSM Beverages. All Rights Reserved.</p>
    </footer>

    <script>
        // Terms checkbox and checkout button logic
        const termsCheckbox = document.getElementById('terms');
        const checkoutBtn = document.getElementById('checkout-btn');

        termsCheckbox.addEventListener('change', () => {
            checkoutBtn.disabled = !termsCheckbox.checked; // Enable/disable button based on checkbox
        });
        
        function updateQuantity(cartID, newQuantity) {
    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'update',
            cartID: cartID,
            quantity: newQuantity
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Cart updated!");
        } else {
            alert("Failed to update quantity.");
        }
    });
}

// Update cart item quantity with client-side validation
function updateQuantity(cartID, newQuantity) {
    if (newQuantity < 1) {
        alert("Quantity cannot be less than 1.");
        return;
    }

    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'update',
            cartID: cartID,
            quantity: newQuantity
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Cart updated!");
            location.reload(); // Refresh page to update cart display
        } else {
            alert("Failed to update quantity.");
        }
    });
}

// Delete an item from the cart
function deleteFromCart(cartID) {
    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'delete',
            cartID: cartID
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Item removed from cart!");
            location.reload(); // Refresh page to update cart display
        } else {
            alert("Failed to remove item.");
        }
    });
}

        
    </script>
</body>
</html>
