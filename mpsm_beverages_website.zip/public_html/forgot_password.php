<?php
require('config.php');
ob_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$emailSent = false;
$errorMessage = '';

function sendMail($email, $token) {
    require("PHPMailer/PHPMailer.php");
    require("PHPMailer/SMTP.php");
    require("PHPMailer/Exception.php");

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'mail.mpsbeverages.co.za';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'support@mpsbeverages.co.za';
        $mail->Password   = 'Mpsmw@t3r1';
        $mail->SMTPSecure = '';  // No encryption needed for port 25 if specified by your provider
        $mail->Port       = 25;

        $mail->setFrom('support@mpsbeverages.co.za', 'MPSM Beverages Support');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Reset Password for MPSM Beverages';
        $mail->Body    = "Thank you for choosing MPSM Beverages!<br>
        Click the link below to reset your password:<br>
        <a href='https://www.mpsbeverages.co.za/resetpassword.php?email=$email&token=$token'>Reset Password</a>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        global $errorMessage;
        $errorMessage = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('config.php');
    $email = $_POST['email'];
    $email = mysqli_real_escape_string($conn, $email);

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $token = bin2hex(random_bytes(50));
        $expires_at = date("Y-m-d H:i:s", strtotime('+1 hour'));

        $sql = "INSERT INTO password_resets (email, token, expires_at) 
                VALUES ('$email', '$token', '$expires_at') 
                ON DUPLICATE KEY UPDATE token='$token', expires_at='$expires_at'";
        mysqli_query($conn, $sql);

        $emailSent = sendMail($email, $token);
    } else {
        $errorMessage = 'No account registered with that email.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Your styling here */
         <style>
        /* Split the screen in half */
        .split {
            height: 100%;
            width: 50%;
            position: fixed;
            z-index: 1;
            top: 0;
            overflow-x: hidden;
            padding-top: 20px;
        }

        /* Control the left side */
        .left {
            left: 0;
            background-color: #efefef;
        }

        /* Control the right side */
        .right {
            right: 0;
            background-color: #efefef;
        }

        /* If you want the content centered horizontally and vertically */
        .centered {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }

            /* Style the image inside the centered container, if needed */
        .centered img {
            top: 80;
            width: 1000px;
            border-radius: 50%;
        }
          /* Header text styling positioned on top of the image */
         .form-header {
            position: absolute;
            top: 0%;
            left: 5%;
            font-size: 5em;
            font-weight: bold;
            color: #FF6B00;
            z-index: 1;
            line-height: 1.2;
        } 
         .form-subheading{
            position: absolute;
            top: 10%;
            left: 20%;
            font-size: 7em;
            font-weight: 1000;
            color: orange;
            z-index: 1;
            line-height: 1.2;
        } 

    
         /* Form container styling */
        .form-container {
            background: #fff;
            padding: 5rem;
            width: 90%;
            height: 90%;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
            border-radius: 12px;
            text-align: center;
        }

        /* Text styling within the form */
        .form-container p {
            font-size: 1em;
            color: #333;
            margin-bottom: 1rem;
        }

        /* Label and input styling */
        .form-container label {
            display: block;
            font-weight: bold;
            color: #555;
            text-align: left;
            margin-bottom: 0.5rem;
        }
        .form-container input[type="email"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 50px;
            font-size: 1em;
            box-sizing: border-box;
            margin-bottom: 1rem;
        }

        /* Button styling */
        .form-container button {
            width: 100%;
            padding: 0.75rem;
            border: none;
            border-radius: 50px;
            background-color: #FF6B00; /* Orange color */
            color: white;
            font-size: 1em;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-container button:hover {
            background-color: orangered;
        }

        /* Link styling */
        .form-container a {
            color: #007bff;
            text-decoration: none;
        }

        .form-container a:hover {
            text-decoration: underline;
        }
    </style>
    </style>
</head>
<body>
    <div class="split left">
        <div class="form-header">Forgot your</div>
        <div class="form-subheading"><span>Password?</span></div>
        <div class="centered"><img src="forgotpassword.jpg" alt="Forgot Password Illustration"></div>
    </div>
    <div class="split right">
        <div class="centered">
            <form class="form-container" action="forgot_password.php" method="POST">
                <p>Enter your email below to receive your password reset link</p>
                <label for="email">Enter your email:</label>
                <input type="email" name="email" placeholder="email@example.com" required>
                <button type="submit">Send Reset Link</button>
                <div>
                    <p style="margin-top: 1rem; font-size: 0.9em;">
                        Not Registered? <a href="registrationpage.php">Register Here</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
    <script>
        // Check PHP flags and display appropriate SweetAlert messages
        <?php if ($emailSent): ?>
            Swal.fire({
                icon: 'success',
                title: 'Email Sent!',
                text: 'A password reset link has been sent to your email. Please check your inbox and spam folder.',
            });
        <?php elseif ($errorMessage): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: "<?php echo $errorMessage; ?>",
            });
        <?php endif; ?>
    </script>
</body>
</html>
